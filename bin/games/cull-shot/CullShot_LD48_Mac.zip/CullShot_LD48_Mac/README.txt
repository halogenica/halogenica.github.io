About the game:
---------------
Shoot a CULL SHOT to reveal enemy cubes.
Capture the cubes to increase the time limit.
Stay alive as long as possible. 

XBOX Controller:
Rotate with left stick
Charge shot by holding A
Shoot by releasing A
Capture by pressing X when shot is over cube

PS3 Controller:
Rotate with left stick
Charge shot by holding X
Shoot by releasing X
Capture by pressing "Square" when shot is over cube

Keyboard:
Rotate with arrow keys
Charge shot by holding space
Shoot by releasing space
Capture by pressing S when shot is over cube

Extra Controls:
F to fullscreen
M to mute music

XBOX (windows) or PS3 (mac) controller recommended


A game by Michael Romero
Made for Ludum Dare 29
http://halogenica.net
