Serendipity with Cubes
by Michael (AngelK) Romero

Serendipity with Cubes is a puzzle solving game!


Rules:
------
*Connect the two pulsating cubes with a pair of same-color cubes
*Click on a cube to select it, and an adjacent cube to swap them
*The goal is to remove all the colored cubes
*If any cubes become stranded, never to be connected, the game is over


Concept:
--------
"Tiny World" brought to mind the idea of how small the world is, 
bringing people together. Then I thought about the game "ticket to ride".
Then I thought about cubes. Then algorithms. Then I started coding.


CONTROLS:
---------
*NOTE: min/max/close window buttons don't work. Exit by pressing Escape.

Exit: ESC
Select Cube: Left Mouse
Rotate World: Right Mouse
Zoom: Scroll Wheel
Increase Num Colors: 0 (up to 5)
Decrease Num Colors: 9 (down to 2)
Increase World Dimension: = (up to 9x9x9)
Decrease World Dimension: - (down to 3x3x3)
Restart: R
Display Stats: S


NOTE:
-----
The game_BUGFIX.exe is a bug fixed version of the game that shouldn't crash!
It was fixed after the compo ended, but is encluded so you can enjoy the game
without the fear of breaking anything :)


TODO:
-----
* music
* min/max/close window buttons
* fullscreen mode
* not all cubes are solvable, but the algorithm tries its best :)
* lighting
* lots and lots of polish