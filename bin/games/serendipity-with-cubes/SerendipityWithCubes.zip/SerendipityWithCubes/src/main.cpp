//#define _CRTDBG_MAP_ALLOC
#include <stdlib.h>
//#include <crtdbg.h>

#include "Common.h"
#include "D3DApp.h"
#include "SDLApp.h"
#include "SDLInput.h"
#include "ObjectManager.h"
#include "Stats.h"
#include "Pool.h"

// include the Direct3D Library files
#pragma comment (lib, "d3d9.lib")
#pragma comment (lib, "d3dx9.lib")

// TODO: new cannot be overloaded here, because it is overloaded by bullet (lame)
//#define new new(_NORMAL_BLOCK,__FILE__,__LINE

//#define DIRECTX
#define SDL

// externs
extern ContactProcessedCallback gContactProcessedCallback;
extern "C" int luaopen_game(lua_State* L);  // declare the wrapped module

// global declarations
Stats*              g_pStats;       // the graphics and physics statistics
IDirect3DDevice9*   g_pDevice;      // the d3d device
IDirect3D9*			pD3D;		    // the d3d instance
App*                g_pApp;         // the application
Input*              g_pInput;       // the input control system
ObjectManager*      pObjectManager;
ID3DXEffect*        g_pFX;          // global shader effect file    TODO: better way to manage this ubershader
SDL_Event           sdlEvent;

// timestep variables
ULONG               timeNow;        // the timestamp of the current frame
ULONG               timePrev;       // the timestamp of the previous frame
ULONG               timeFrame;      // the time delta for the current frame
ULONG               timeSum;        // accumulation of time
const ULONG         timeDelta = 1;  // the constant update time delta
const ULONG         timeMax = 16;   // the constant maximum time delta

// bullet variables
btBroadphaseInterface*                  pBtBroadphase;              // the broadphase
btDefaultCollisionConfiguration*        pBtCollisionConfiguration;  // the collision config
btCollisionDispatcher*                  pBtDispatcher;              // the dispatch config
btSequentialImpulseConstraintSolver*    pBtSolver;                  // the physics solver
btDiscreteDynamicsWorld*                g_pBtDynamicsWorld;           // the world
btCollisionShape*                       pBtGroundShape;             // the ground
btDefaultMotionState*                   pBtGroundMotionState;
btRigidBody*                            pBtGroundRigidBody;

// function prototypes
void InitBullet();              // initialize bullet physics
void InitOpenAL();              // initializes OpenAL audio
void LoadScene();               // load the scene
void Update(float dt);          // updates the simulation
void RenderFrame();             // renders a single frame
void DestroyBullet();           // free memory used by bullet physics
void DestroyOpenAL();           // uninitialize OpenAL and free the device
static bool CollisionCallback(btManifoldPoint& point, btCollisionObject* body0, btCollisionObject* body1);


// the entry point for any Windows program
int WINAPI WinMain(HINSTANCE hInstance,
                   HINSTANCE hPrevInstance,
                   LPSTR lpCmdLine,
                   int nCmdShow)
{
    timePrev = timeGetTime();
    timeNow  = 0;
    timeSum = 0;

    InitBullet();   // Must init bullet before statics
    InitOpenAL();
#if defined(DIRECTX)
    g_pApp = new D3DApp(&g_pDevice, hInstance, nCmdShow, SCREEN_WIDTH, SCREEN_HEIGHT);
    g_pInput = new D3DInput(hInstance, GetActiveWindow(), DISCL_NONEXCLUSIVE|DISCL_FOREGROUND, DISCL_NONEXCLUSIVE|DISCL_FOREGROUND);
#elif defined(SDL)
    g_pApp = new SDLApp(&g_pDevice, hInstance, nCmdShow, SCREEN_WIDTH, SCREEN_HEIGHT);
    g_pInput = new SDLInput();
#else
// Need to define either DIRECTX or SDL
CASSERT(false);
#endif
    g_pStats = new Stats(g_pDevice);
    D3DXCreateEffectFromResource(g_pDevice, NULL, MAKEINTRESOURCE(IDR_EFFECT1), 0, 0, D3DXSHADER_DEBUG, 0, &g_pFX, 0);
    ObjectManager::Init();
    LoadScene();

    MSG msg;

    while(TRUE)
    {

        g_pApp->CheckMessage(&msg);

        if(msg.message == WM_QUIT)
        {
            break;
        }
    
        timeNow = timeGetTime();
        timeFrame = timeNow - timePrev;
        timePrev = timeNow;

		g_pStats->updateFPS(timeFrame * .001f);    // g_pStats uses time in seconds

        // practical limitation, don't let updates overcome framerate
        if (timeFrame > timeMax)
        {
            timeFrame = timeMax;
        }

        timeSum += timeFrame;

        // update at a rate of timeDiff, regardless of framerate
        while (timeSum >= timeDelta)
        {
            Update(timeDelta * .001f);
            g_pBtDynamicsWorld->stepSimulation(timeDelta*.001f, 1, timeMax*.001f); 
            g_pStats->updateUPS(timeDelta * .001f);    // g_pStats uses time in seconds
            timeSum -= timeDelta;
        }

        // render once per frame
        RenderFrame();
    }

    ObjectManager::Destroy();
    delete g_pStats;

    delete g_pInput;   // TODO: Resolve who owns g_pInput: either main or app
    delete g_pApp;

    DestroyOpenAL();
    DestroyBullet();
//    _CrtDumpMemoryLeaks();  // TODO: remove code checking for memory leaks
    return msg.wParam;
}


void InitBullet()
{
    // Build the broadphase
    pBtBroadphase = new btDbvtBroadphase();
 
    // Set up the collision configuration and dispatcher
    pBtCollisionConfiguration = new btDefaultCollisionConfiguration();
    pBtDispatcher = new btCollisionDispatcher(pBtCollisionConfiguration);
 
    // The actual physics solver
    pBtSolver = new btSequentialImpulseConstraintSolver;
 
    // The world
    g_pBtDynamicsWorld = new btDiscreteDynamicsWorld(pBtDispatcher,pBtBroadphase,pBtSolver,pBtCollisionConfiguration);
    g_pBtDynamicsWorld->setGravity(btVector3(0, GRAVITY_CONST, 0));

    gContactProcessedCallback = (ContactProcessedCallback)CollisionCallback;
}


void InitOpenAL()
{
    // Init openAL
    alutInit(0, NULL);
    // Clear Error Code (so we can catch any new errors)
    alGetError();

    // TODO: ALUT doesn't have native support for loading OGG files
    ALuint buffer = alutCreateBufferFromFile("res\\test_stereo.wav");

    ALuint source;
    alGenSources(1, &source);
    alSourcei(source, AL_BUFFER, buffer);
    alSourcei(source, AL_LOOPING, AL_TRUE);

//    alSourcePlay(source);

    int error = alGetError();
    if (error)
    {
        DebugPrint(L"%s\n", alutGetErrorString(error));
    }
}


void LoadScene()
{
    RECT rect = { 0, 0, SCREEN_WIDTH, SCREEN_HEIGHT };
    DWORD style = WS_OVERLAPPEDWINDOW;
    AdjustWindowRect(&rect, style, FALSE);

    /*
    lua_State* L;
    L=lua_open();
    //luaopen_base(L);        // load basic libs (eg. print)
    luaL_openlibs(L);
    luaopen_game(L);    // load the wrappered module

    if (luaL_loadfile(L,".\\scripts\\scene.lua")==0) // load and run the file
    {
        DebugPrint(L"loaded .\\scripts\\scene.lua");
        lua_pcall(L,0,0,0);
    }
    else
    {
        DebugPrint(L"unable to load .\\scripts\\scene.lua");
    }

    lua_close(L);
    */
}


void Update(float dt)
{
    pObjectManager->Update(dt);
}


void RenderFrame()
{
    // clear the window
    g_pDevice->Clear(0, NULL, D3DCLEAR_TARGET, D3DCOLOR_XRGB(0x4C, 0x4C, 0x4C), 1.0f, 0);
    g_pDevice->Clear(0, NULL, D3DCLEAR_ZBUFFER, D3DCOLOR_XRGB(0, 0, 0), 1.0f, 0);

    HR(g_pDevice->BeginScene());    // begins the 3D scene

    // set up the pipeline
    pObjectManager->Render();

    HR(g_pDevice->EndScene());    // ends the 3D scene

    HRESULT hr = g_pDevice->Present(NULL, NULL, NULL, NULL);   // displays the created frame on the screen

    if (hr == D3DERR_DEVICELOST)
    {
        while (true)
        {
            hr = g_pDevice->TestCooperativeLevel();
            switch (hr)
            {
                case D3D_OK:
                    return;
                case D3DERR_DEVICELOST:
                    break;
                case D3DERR_DEVICENOTRESET:
                    pObjectManager->Reset();
                    break;
                default:
                    ASSERT(false);  // Fatal error
                    return;
            }
            Sleep(20);
        }
    }
}


void DestroyBullet()
{
    delete g_pBtDynamicsWorld;
    delete pBtSolver;
    delete pBtDispatcher;
    delete pBtCollisionConfiguration;
    delete pBtBroadphase;
    delete pBtGroundShape;
}


void DestroyOpenAL()
{
    alutExit();
}


void DestroyScene()
{
    SDL_Quit();
}

static bool CollisionCallback(btManifoldPoint& point, btCollisionObject* body0, btCollisionObject* body1)
{
#if 0
    int numManifolds = g_pBtDynamicsWorld->getDispatcher()->getNumManifolds();

    Pool<Enemy*>::const_iterator enemy;

    btPersistentManifold* contactManifold = NULL;
    btCollisionObject* obA = NULL;
    btCollisionObject* obB = NULL;
    ObjectData* pObjA = NULL;
    ObjectData* pObjB = NULL;
    Enemy* pEnemy = NULL;

    for (int i = 0; i < numManifolds; i++)
    {
        contactManifold = g_pBtDynamicsWorld->getDispatcher()->getManifoldByIndexInternal(i);
        obA = static_cast<btCollisionObject*>(contactManifold->getBody0());
        obB = static_cast<btCollisionObject*>(contactManifold->getBody1());

        pObjA = reinterpret_cast<ObjectData*>(obA->getUserPointer());
        ASSERT(pObjA);
        ASSERT(pObjA->m_pPhysicsData);
        pObjB = reinterpret_cast<ObjectData*>(obB->getUserPointer());
        ASSERT(pObjB);
        ASSERT(pObjB->m_pPhysicsData);

        /*
        // Demonstrates how to determine the physics group for each object in the manifold.
        DebugPrint(L"Collision Flags (Object A): %d\n", pPhysA->m_InitPhysicsData.CollisionGroup);
        DebugPrint(L"Collision Flags (Object B): %d\n", pPhysB->m_InitPhysicsData.CollisionGroup);
        */

        if (pObjA->m_pPhysicsData->m_InitPhysicsData.CollisionGroup == COL_BULLET && 
            pObjB->m_pPhysicsData->m_InitPhysicsData.CollisionGroup == COL_HITCORE)
        {
            pEnemy = static_cast<Enemy*>(pObjB);

        }
        else if (pObjA->m_pPhysicsData->m_InitPhysicsData.CollisionGroup == COL_HITCORE && 
                 pObjB->m_pPhysicsData->m_InitPhysicsData.CollisionGroup == COL_BULLET)
        {
            pEnemy = static_cast<Enemy*>(pObjA);
        }

        if (pEnemy)
        {
            pEnemy->Hit();
        }

        pEnemy = NULL;
    }
#endif
    return true;
}
