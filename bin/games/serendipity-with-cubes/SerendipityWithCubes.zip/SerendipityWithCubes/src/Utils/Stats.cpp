
#include "Common.h"
#include "Stats.h"
#include "RenderData.h"
#include <tchar.h>

TextureVertex Stats::m_UIBoxVertices[] = 
{
    {{-0.5,  0.5, 0}, WHITE, 0.f, 0.f},
    {{ 0.5,  0.5, 0}, WHITE, 1.f, 0.f},
    {{ 0.5, -0.5, 0}, WHITE, 1.f, 1.f},

    {{-0.5,  0.5, 0}, WHITE, 0.f, 0.f},
    {{ 0.5, -0.5, 0}, WHITE, 1.f, 1.f},
    {{-0.5, -0.5, 0}, WHITE, 0.f, 1.f},
};

Stats::Stats(IDirect3DDevice9* pDevice)
: m_pDevice(pDevice), mFont(0), m_pVB(NULL), m_pVertexDecl(NULL), m_pTexture(NULL), mFPS(0.0f), mUPS(0.0f), mMilliSecPerFrame(0.0f), mNumTris(0), mNumVertices(0), mNumRigidBodies(0), mCursorX(0), mCursorY(0)
{
    AddFontResource(L"res\\ProFontWindows.ttf");

	D3DXFONT_DESC fontDesc;
	fontDesc.Height          = 24;
    fontDesc.Width           = 0;
    fontDesc.Weight          = FW_NORMAL;
    fontDesc.MipLevels       = 2;
    fontDesc.Italic          = false;
    fontDesc.CharSet         = DEFAULT_CHARSET;
    fontDesc.OutputPrecision = OUT_DEFAULT_PRECIS;
    fontDesc.Quality         = ANTIALIASED_QUALITY;
    fontDesc.PitchAndFamily  = DEFAULT_PITCH | FF_DONTCARE;
    wcscpy_s(fontDesc.FaceName, L"ProFontWindows");

	D3DXCreateFontIndirect(m_pDevice, &fontDesc, &mFont);

    // Create a backdrop
    fontDesc.Weight         = FW_BOLD;
	D3DXCreateFontIndirect(m_pDevice, &fontDesc, &mFontBackdrop);

    // Create a quad
    // Create vertex decl
    if (NULL == m_pVertexDecl)  // Protection for multiple OnResetDevice after Reset
    {
        HR(g_pDevice->CreateVertexDeclaration(TextureVertexDeclElements, &m_pVertexDecl));
    }

    void* pLockedBuff;

    // Create vertex buffer
    if (NULL == m_pVB)  // Protection for multiple OnResetDevice after Reset
    {
        HR(g_pDevice->CreateVertexBuffer(sizeof(TextureVertex)*6,
                                         D3DUSAGE_WRITEONLY,
                                         0,
                                         D3DPOOL_DEFAULT,
                                         &m_pVB,
                                         NULL));

        HR(m_pVB->Lock(0, 0, (void**)&pLockedBuff, 0));
        memcpy(pLockedBuff, m_UIBoxVertices, sizeof(TextureVertex)*6);
        HR(m_pVB->Unlock());
    }

    // Load texture
    D3DXIMAGE_INFO SrcInfo;         //Optional
    //Use a magenta colorkey
    D3DCOLOR colorkey = 0xffff00ff;
    D3DXCreateTextureFromFileEx(g_pDevice, L"res\\scorebox_512x198.png", 0, 0, 1, 0, D3DFMT_A8R8G8B8, D3DPOOL_MANAGED, D3DX_FILTER_TRIANGLE, D3DX_DEFAULT, colorkey, &SrcInfo, NULL, &m_pTexture);

    // Transform textured quad
    D3DXMatrixIdentity(&m_transform);

    D3DXMATRIX matTrans;
    D3DXMATRIX matRotate;
    D3DXMATRIX matScale;

    D3DXMatrixScaling(&matScale, 20, 20, 20);
    D3DXMatrixTranslation(&matTrans, 32, 16, 0);
    D3DXMatrixIdentity(&matRotate);

    m_transform = matScale * matTrans * matRotate;
}

Stats::~Stats()
{
	ReleaseCOM(mFont);
	ReleaseCOM(mFontBackdrop);
    ReleaseCOM(m_pVertexDecl);
	ReleaseCOM(m_pVB);
    ReleaseCOM(m_pTexture);
}

void Stats::OnLostDevice()
{
	mFont->OnLostDevice();
}

void Stats::OnResetDevice()
{
	mFont->OnResetDevice();
}

void Stats::addVertices(DWORD n)         {mNumVertices += n;     }
void Stats::subVertices(DWORD n)         {mNumVertices -= n;     }
void Stats::addTriangles(DWORD n)        {mNumTris += n;         }
void Stats::subTriangles(DWORD n)        {mNumTris -= n;         }
void Stats::addRigidBodies(DWORD n)      {mNumRigidBodies += n;  }
void Stats::subRigidBodies(DWORD n)      {mNumRigidBodies -= n;  }
void Stats::setTriCount(DWORD n)         {mNumTris = n;          }
void Stats::setVertexCount(DWORD n)      {mNumVertices = n;      }
void Stats::setRigidBodyCount(DWORD n)   {mNumRigidBodies = n;   }

void Stats::setCursorPosition(float x, float y) {mCursorX = x; mCursorY = y;}

void Stats::updateFPS(float dt)
{
	// Make static so that their values persist accross function calls.
	static float numFrames   = 0.0f;
	static float timeElapsed = 0.0f;

	// Increment the frame count.
	numFrames += 1.0f;

	// Accumulate how much time has passed.
	timeElapsed += dt;

	// Has one second passed?--we compute the frame statistics once 
	// per second.  Note that the time between frames can vary so 
	// these stats are averages over a second.
	if( timeElapsed >= 1.0f )
	{
		// Frames Per Second = numFrames / timeElapsed,
		// but timeElapsed approx. equals 1.0, so 
		// frames per second = numFrames.

		mFPS = numFrames;

		// Average time, in miliseconds, it took to render a single frame.
		mMilliSecPerFrame = 1000.0f / mFPS;

		// Reset time counter and frame count to prepare for computing
		// the average stats over the next second.
		timeElapsed = 0.0f;
		numFrames   = 0.0f;
	}
}

void Stats::updateUPS(float dt)
{
	// Make static so that their values persist accross function calls.
	static float numUpdates  = 0.0f;
	static float timeElapsed = 0.0f;

	// Increment the frame count.
	numUpdates += 1.0f;

	// Accumulate how much time has passed.
	timeElapsed += dt;

	// Has one second passed?--we compute the frame statistics once 
	// per second.  Note that the time between frames can vary so 
	// these stats are averages over a second.
	if( timeElapsed >= 1.0f )
	{
		// Frames Per Second = numFrames / timeElapsed,
		// but timeElapsed approx. equals 1.0, so 
		// frames per second = numFrames.

		mUPS = numUpdates;

		// Average time, in miliseconds, it took to render a single frame.
		mMilliSecPerUpdate = 1000.0f / mUPS;

		// Reset time counter and frame count to prepare for computing
		// the average stats over the next second.
		timeElapsed = 0.0f;
		numUpdates   = 0.0f;
	}
}

void Stats::display()
{
	// Make static so memory is not allocated every frame.
	static wchar_t buffer[512];

	swprintf_s(buffer, L"Frames Per Second = %.2f\n"
        L"Updates Per Second = %.2f\n"
		L"Milliseconds Per Frame = %.4f\n"
		L"Triangle Count = %d\n"
		L"Vertex Count = %d\n"
        L"Rigid Bodies = %d\n", mFPS, mUPS, mMilliSecPerFrame, mNumTris, mNumVertices, mNumRigidBodies);

	RECT R = {5, 5, 20, 10};


    // position textured quad
    HR(m_pDevice->SetTransform(D3DTS_WORLD, &m_transform));
    HR(g_pDevice->SetTexture(0, m_pTexture));
    HR(m_pDevice->SetVertexDeclaration(m_pVertexDecl));
    HR(g_pDevice->SetStreamSource(0, m_pVB, 0, sizeof(TextureVertex)));
//    HR(g_pDevice->DrawPrimitive(D3DPT_TRIANGLELIST, 0, 2));

    // TODO: line up backdrop with foreground text
//	mFontBackdrop->DrawText(0, buffer, -1, &R, DT_NOCLIP, D3DCOLOR_XRGB(0xFF,0xFF,0xFF));
    mFont->DrawText(        0, buffer, -1, &R, DT_NOCLIP, D3DCOLOR_XRGB(0xFF,0x66,0x00));
}