
#pragma once

#include "Common.h"
#include "Vertex.h"

class Stats
{
public:
	Stats(IDirect3DDevice9* m_pDevice);
	~Stats();

	void OnLostDevice();
	void OnResetDevice();

	void addVertices(DWORD n);
	void subVertices(DWORD n);
	void addTriangles(DWORD n);
	void subTriangles(DWORD n);
    void addRigidBodies(DWORD n);
	void subRigidBodies(DWORD n);
    void setCursorPosition(float x, float y);

	void setTriCount(DWORD n);
	void setVertexCount(DWORD n);
    void setRigidBodyCount(DWORD n);

	void updateFPS(float dt);
    void updateUPS(float dt);
    void display();


	float mFPS;
    float mUPS;

private:
	// Prevent copying
	Stats(const Stats& rhs);
	Stats& operator=(const Stats& rhs);
	
private:
	IDirect3DDevice9* m_pDevice;
	ID3DXFont* mFont;
	ID3DXFont* mFontBackdrop;

    static TextureVertex            m_UIBoxVertices[];
    IDirect3DVertexDeclaration9*    m_pVertexDecl;
	IDirect3DVertexBuffer9*         m_pVB;
    IDirect3DTexture9*              m_pTexture;
    D3DXMATRIX                      m_transform;

	float mMilliSecPerFrame;
    float mMilliSecPerUpdate;
	DWORD mNumTris;
	DWORD mNumVertices;
    DWORD mNumRigidBodies;
    float mCursorX;
    float mCursorY;
};
