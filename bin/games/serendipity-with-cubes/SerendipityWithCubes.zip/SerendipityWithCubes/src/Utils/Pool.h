
#pragma once

#include "Common.h"
#include <list>


template <class T>
class Pool : public std::list<T>
{
public:

    Pool(){}
    ~Pool()
    {
        std::list<T>::const_iterator i = begin();
        while (i != end())
        {
            delete *i;
            i = erase(i);
        }
    }

    void Add(const T& pItem);
    void Remove(const T& pItem);
    void Draw(const D3DXMATRIX& transform);
    void Update(const float& dt);
    bool Contains(const T& pItem);
};

template <class T>
inline void Pool<T>::Add(const T& pItem)
{
    push_back(pItem);
}

template <class T>
inline void Pool<T>::Remove(const T& pItem)
{
    remove(pItem);
}

template <class T>
inline void Pool<T>::Draw(const D3DXMATRIX& transform)
{
    std::list<T>::const_iterator i;
    for (i = begin(); i != end(); ++i)
    {
        (*i)->Draw(transform);
    }
}

template <class T>
inline void Pool<T>::Update(const float& dt)
{
    std::list<T>::const_iterator i;
    i = begin();
    while(i != end())
    {
        if(!(*i)->Update(dt))
        {
            delete *i;
            i = erase(i);
        }
        else
        {
            ++i;
        }
    }
}

template <class T>
inline bool Pool<T>::Contains(const T& pItem)
{
    std::list<T>::const_iterator i;
    for (i = begin(); i != end(); ++i)
    {
        if ((*i) == pItem)
        {
            return true;
        }
    }
    return false;
}