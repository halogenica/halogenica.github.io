While this contains the source used for the game, this code does not
compile as it does not contain the engine source code. Unfortunately
the engine is tied tightly with the game, and the engine is not yet
intended to be released. However, with what is provided here, it
should be easy to recreate this game with another 3d engine with
similar features :)

Sorry for the inconvenience!

-Mike