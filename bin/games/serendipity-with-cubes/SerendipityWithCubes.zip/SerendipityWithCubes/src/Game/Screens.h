
#pragma once

#include "Common.h"

class Screens
{
public:

    Screens(IDirect3DDevice9* pDevice);
    ~Screens();

    void Draw();

private:
    IDirect3DDevice9*   m_pDevice;
	ID3DXFont*          m_pFont;
	ID3DXFont*          m_pBigFont;
    IDirect3DTexture9*  m_pTitleTexture;
    IDirect3DTexture9*  m_pScreenTexture;
    IDirect3DTexture9*  m_pBoxTexture;
    ID3DXSprite*        m_pSprite; 
};