
#include "Screens.h"
#include "ObjectManager.h"

Screens::Screens(IDirect3DDevice9* pDevice) : m_pDevice(pDevice)
{
    AddFontResource(L"res\\ProFontWindows.ttf");

	D3DXFONT_DESC fontDesc;
	fontDesc.Height          = 24;
    fontDesc.Width           = 0;
    fontDesc.Weight          = FW_NORMAL;
    fontDesc.MipLevels       = 2;
    fontDesc.Italic          = false;
    fontDesc.CharSet         = DEFAULT_CHARSET;
    fontDesc.OutputPrecision = OUT_DEFAULT_PRECIS;
    fontDesc.Quality         = ANTIALIASED_QUALITY;
    fontDesc.PitchAndFamily  = DEFAULT_PITCH | FF_DONTCARE;
    wcscpy_s(fontDesc.FaceName, L"ProFontWindows");

    HR(D3DXCreateFontIndirect(m_pDevice, &fontDesc, &m_pFont));

    fontDesc;
    fontDesc.Height         = 80;
    HR(D3DXCreateFontIndirect(m_pDevice, &fontDesc, &m_pBigFont));

    // Load texture
    D3DXIMAGE_INFO SrcInfo;         //Optional
    // Magenta colorkey
    D3DCOLOR colorkey = 0xFFFF00FF;
    HR(D3DXCreateTextureFromFileEx(g_pDevice, L"res\\background1024.png", 0, 0, 1, 0, D3DFMT_A8R8G8B8, D3DPOOL_MANAGED, D3DX_FILTER_TRIANGLE, D3DX_DEFAULT, colorkey, &SrcInfo, NULL, &m_pScreenTexture));
    HR(D3DXCreateTextureFromFileEx(g_pDevice, L"res\\title1024.png", 0, 0, 1, 0, D3DFMT_A8R8G8B8, D3DPOOL_MANAGED, D3DX_FILTER_TRIANGLE, D3DX_DEFAULT, colorkey, &SrcInfo, NULL, &m_pTitleTexture));
    HR(D3DXCreateTextureFromFileEx(g_pDevice, L"res\\box.png", 0, 0, 1, 0, D3DFMT_A8R8G8B8, D3DPOOL_MANAGED, D3DX_FILTER_TRIANGLE, D3DX_DEFAULT, colorkey, &SrcInfo, NULL, &m_pBoxTexture));

    // Create sprite
    HR(D3DXCreateSprite(m_pDevice, &m_pSprite));
}

Screens::~Screens()
{
    ReleaseCOM(m_pFont);
    ReleaseCOM(m_pSprite);
    ReleaseCOM(m_pScreenTexture);
    ReleaseCOM(m_pTitleTexture);
    ReleaseCOM(m_pBoxTexture);
}

void Screens::Draw()
{
	// Make static so memory is not allocated every frame.
	static wchar_t buffer[512];
    RECT R;

    D3DXVECTOR3 spritePos;
    spritePos.x = 128;
    spritePos.y = -100;
    spritePos.z = 0;

    /*
    // Hardcoded, background is 1024x1024
    D3DXVECTOR2 spriteCenter = D3DXVECTOR2(512, 512);

    D3DXMATRIX mat;
    D3DXVECTOR2 scale(1.0f,1.0f);
    D3DXMatrixTransformation2D(&mat,NULL,0.0,&scale,&spriteCenter,0,&spritePos);
    m_pSprite->SetTransform(&mat);
    */


    switch(ObjectManager::gameState)
    {
        case NEW_GAME_SCREEN_1:
            m_pSprite->Begin(D3DXSPRITE_ALPHABLEND);
            m_pSprite->Draw(m_pTitleTexture, NULL, NULL, &spritePos, D3DCOLOR_COLORVALUE(1.0f,1.0f,1.0f,1.0f));
            m_pSprite->End();
            break;
        case NEW_GAME_SCREEN_2:
    	    swprintf_s(buffer, 
                L"RULES:\n"
                L"------\n"
                L"\n"
                L"- Connect the two pulsating cubes using a path of same-color cubes\n"
                L"- Click on a cube to select it, and an adjacent cube to swap them\n"
                L"- The goal is to remove all the colored cubes\n"
                L"- If any cubes become stranded, never to be connected, the game is over\n"
                );
            m_pSprite->Begin(D3DXSPRITE_ALPHABLEND);
            m_pSprite->Draw(m_pScreenTexture, NULL, NULL, &spritePos, D3DCOLOR_COLORVALUE(1.0f,1.0f,1.0f,1.0f));
            m_pSprite->End();
            R.top = 200;
            R.left = 200;
            R.bottom = SCREEN_HEIGHT-150;
            R.right = SCREEN_WIDTH-150;
            m_pFont->DrawText(0, buffer, -1, &R, DT_NOCLIP, D3DCOLOR_XRGB(0xFF,0xFF,0xFF));
            break;
        case NEW_GAME_SCREEN_3:
    	    swprintf_s(buffer,
                L"CONTROLS:\n"
                L"---------\n"
                L"\n"
                L"Exit: ESC\n"
                L"Restart: R\n"
                L"\n"
                L"Select Cube: Left Mouse\n"
                L"Rotate World: Right Mouse\n"
                L"Zoom: Scroll Wheel\n"
                L"\n"
                L"Increase Num Colors: 0 (up to 5)\n"
                L"Decrease Num Colors: 9 (down to 2)\n"
                L"Increase World Dimension: = (up to 9x9x9)\n"
                L"Decrease World Dimension: - (down to 3x3x3)\n"
                L"\n"
                L"Display Stats: S\n"
                );
            m_pSprite->Begin(D3DXSPRITE_ALPHABLEND);
            m_pSprite->Draw(m_pScreenTexture, NULL, NULL, &spritePos, D3DCOLOR_COLORVALUE(1.0f,1.0f,1.0f,1.0f));
            m_pSprite->End();
            R.top = 200;
            R.left = 200;
            R.bottom = SCREEN_HEIGHT-150;
            R.right = SCREEN_WIDTH-150;
            m_pFont->DrawText(0, buffer, -1, &R, DT_NOCLIP, D3DCOLOR_XRGB(0xFF,0xFF,0xFF));
            break;
        case GAME_OVER:
    	    swprintf_s(buffer, L"GAME OVER!");
            spritePos.x = 384;
            spritePos.y = 100;
            m_pSprite->Begin(D3DXSPRITE_ALPHABLEND);
            m_pSprite->Draw(m_pBoxTexture, NULL, NULL, &spritePos, D3DCOLOR_COLORVALUE(1.0f,1.0f,1.0f,1.0f));
            m_pSprite->End();
            R.top = 320;
            R.left = 445;
            R.bottom = SCREEN_HEIGHT-150;
            R.right = SCREEN_WIDTH-150;
            m_pBigFont->DrawText(0, buffer, -1, &R, DT_NOCLIP, D3DCOLOR_XRGB(0xFF,0xFF,0xFF));
            break;
        case GAME_WON:
    	    swprintf_s(buffer, L"YOU WIN!");
            spritePos.x = 384;
            spritePos.y = 100;
            m_pSprite->Begin(D3DXSPRITE_ALPHABLEND);
            m_pSprite->Draw(m_pBoxTexture, NULL, NULL, &spritePos, D3DCOLOR_COLORVALUE(1.0f,1.0f,1.0f,1.0f));
            m_pSprite->End();
            R.top = 320;
            R.left = 480;
            R.bottom = SCREEN_HEIGHT-150;
            R.right = SCREEN_WIDTH-150;
            m_pBigFont->DrawText(0, buffer, -1, &R, DT_NOCLIP, D3DCOLOR_XRGB(0xFF,0xFF,0xFF));
            break;
        default:
            break;
    }
}