
#include "World.h"
#include "ObjectManager.h"
#include <time.h>

ALuint World::m_soundSelect     = 0;
ALuint World::m_soundBadSelect  = 0;
ALuint World::m_soundSwap       = 0;
ALuint World::m_soundPathClear  = 0;
ALuint World::m_soundDead       = 0;
ALuint World::m_soundWin        = 0;

World::World(IDirect3DDevice9* pDevice, Camera* pCamera, UINT dim, UINT numColors, float scale) : 
    m_pDevice(pDevice), m_pCamera(pCamera), m_dim(dim), m_scale(scale), m_numColors(numColors), m_pSelectedCube(NULL)
{   
    ASSERT(m_dim >= 3);
    ASSERT(NUM_FACES == 6); // init assumes 6 faces
    ASSERT(m_numColors <= MAX_COLORS);

    // initialize random generator
    srand((UINT)time(NULL));

    // initialize eye candy
    m_pulseInc = 0.001f;
    m_pulseFactor = 1.0f;
    m_maxPulseFactor = 1.2f;
    m_minPulseFactor = 0.8f;

    m_cursorCoords = btVector3(g_pInput->MouseX(), g_pInput->MouseY(), FAR_CLIP);
    m_pCubePool = new Pool<CCube*>;      // pool holding pointers to each cube, for convenience
    m_pPathPool = new Pool<CCube*>;      // pool holding cubes in a path traversal, for solving a path

    // dynamic multi-dimensional array
    m_pCubeArray = new CCube***[NUM_FACES];
    for (UINT face = 0; face < NUM_FACES; face++)
    {
        m_pCubeArray[face] = new CCube**[m_dim];
        for (UINT row = 0; row < m_dim; row++)
        {
            m_pCubeArray[face][row] = new CCube*[m_dim];
        }
    }

    CCube* pCube = NULL;                 // temp variable for creating new cubes

    // init the array by nulling it out
    for (UINT face = 0; face < NUM_FACES; face++)
    {
        for (UINT x = 0; x < m_dim; x++)
        {
            for (UINT y = 0; y < m_dim; y++)
            {
                m_pCubeArray[face][y][x] = NULL;
            }
        }
    }

    // init cube color info
    m_numCubes = ((m_dim-2) * (m_dim-2)) * NUM_FACES; // num unique cubes per face
    m_numCubes += (m_dim-2) * 12;                     // num cubes shared by 2 faces
    m_numCubes += 8;                                  // num corners

    m_maxColorCubes = (UINT)(m_numCubes/m_numColors);
    if (m_numCubes % m_numColors != 0)
    {
        m_maxColorCubes += 1;    // add 1 to round up
    }

    ASSERT(m_maxColorCubes * m_numColors >= m_numCubes);

    m_pNumColorCubes = new UINT[m_numColors];
    for (UINT i = 0; i < m_numColors; i++)
    {
        m_pNumColorCubes[i] = 0;
    }

    // init big cube in the middle
    {
        float bigCubeScale = (m_dim-2)*m_scale;
        m_pBigCube = new Cube(true, true, btVector3(0,0,0), bigCubeScale, GREY, COL_BULLET, COL_EVERYTHING);   // COL_BULLET is arbitrary, just not COL_PARTICLE

        // Make cube immovable
        PhysicsData* pPhysData = m_pBigCube->GetPhysicsData();
        ASSERT(pPhysData);
        pPhysData->UnregisterPhysics();
        pPhysData->m_pBtRigidBody->setMassProps(0, btVector3(0,0,0));
        pPhysData->m_pBtRigidBody->clearForces();
        pPhysData->m_pBtRigidBody->activate();
        pPhysData->RegisterPhysics();
    }

    // init unique cubes for each face
    for (UINT face = 0; face < NUM_FACES; face++)
    {
        for (UINT x = 1; x < m_dim-1; x++)
        {
            for (UINT y = 1; y < m_dim-1; y++)
            {
                pCube = MakeRandCube((CUBE_FACE)face, y, x);    // gross but whatever
                m_pCubePool->Add(pCube);
                m_pCubeArray[face][y][x]    = pCube;
            }
        }
    }

    // init sides
    for (UINT i = 1; i < m_dim-1; i++)
    {
        // top and back
        pCube = MakeRandCube(TOP, 0, i);
        m_pCubePool->Add(pCube);
        m_pCubeArray[TOP][0][i]             = pCube;
        m_pCubeArray[BACK][0][m_dim-1-i]      = pCube;

        // top and front
        pCube = MakeRandCube(TOP, m_dim-1, i);
        m_pCubePool->Add(pCube);
        m_pCubeArray[TOP][m_dim-1][i]         = pCube;
        m_pCubeArray[FRONT][0][i]           = pCube;

        // top and left
        pCube = MakeRandCube(TOP, i, 0);
        m_pCubePool->Add(pCube);
        m_pCubeArray[TOP][i][0]             = pCube;
        m_pCubeArray[LEFT][0][i]            = pCube;

        // top and right
        pCube = MakeRandCube(TOP, i, m_dim-1);
        m_pCubePool->Add(pCube);
        m_pCubeArray[TOP][i][m_dim-1]         = pCube;
        m_pCubeArray[RIGHT][0][m_dim-1-i]     = pCube;

        // bottom and front
        pCube = MakeRandCube(BOTTOM, 0, i);
        m_pCubePool->Add(pCube);
        m_pCubeArray[BOTTOM][0][i]          = pCube;
        m_pCubeArray[FRONT][m_dim-1][i]       = pCube;

        // bottom and back
        pCube = MakeRandCube(BOTTOM, m_dim-1, i);
        m_pCubePool->Add(pCube);
        m_pCubeArray[BOTTOM][m_dim-1][i]      = pCube;
        m_pCubeArray[BACK][m_dim-1][m_dim-1-i]  = pCube;

        // bottom and left
        pCube = MakeRandCube(BOTTOM, i, 0);
        m_pCubePool->Add(pCube);
        m_pCubeArray[BOTTOM][i][0]          = pCube;
        m_pCubeArray[LEFT][m_dim-1][m_dim-1-i]  = pCube;

        // bottom and right
        pCube = MakeRandCube(BOTTOM, i, m_dim-1);
        m_pCubePool->Add(pCube);
        m_pCubeArray[BOTTOM][i][m_dim-1]      = pCube;
        m_pCubeArray[RIGHT][m_dim-1][i]       = pCube;

        // front and left
        pCube = MakeRandCube(FRONT, i, 0);
        m_pCubePool->Add(pCube);
        m_pCubeArray[FRONT][i][0]           = pCube;
        m_pCubeArray[LEFT][i][m_dim-1]        = pCube;

        // front and right
        pCube = MakeRandCube(FRONT, i, m_dim-1);
        m_pCubePool->Add(pCube);
        m_pCubeArray[FRONT][i][m_dim-1]       = pCube;
        m_pCubeArray[RIGHT][i][0]           = pCube;

        // back and left
        pCube = MakeRandCube(BACK, i, m_dim-1);
        m_pCubePool->Add(pCube);
        m_pCubeArray[BACK][i][m_dim-1]        = pCube;
        m_pCubeArray[LEFT][i][0]            = pCube;

        // back and right
        pCube = MakeRandCube(BACK, i, 0);
        m_pCubePool->Add(pCube);
        m_pCubeArray[BACK][i][0]            = pCube;
        m_pCubeArray[RIGHT][i][m_dim-1]       = pCube;
    }

    // init corners
    {
        // top front left
        pCube = MakeRandCube(TOP, m_dim-1, 0);
        m_pCubePool->Add(pCube);
        m_pCubeArray[TOP][m_dim-1][0]         = pCube;
        m_pCubeArray[FRONT][0][0]           = pCube;
        m_pCubeArray[LEFT][0][m_dim-1]        = pCube;

        // top front right
        pCube = MakeRandCube(TOP, m_dim-1, m_dim-1);
        m_pCubePool->Add(pCube);
        m_pCubeArray[TOP][m_dim-1][m_dim-1]     = pCube;
        m_pCubeArray[FRONT][0][m_dim-1]       = pCube;
        m_pCubeArray[RIGHT][0][0]           = pCube;

        // top back left
        pCube = MakeRandCube(TOP, 0, 0);
        m_pCubePool->Add(pCube);
        m_pCubeArray[TOP][0][0]             = pCube;
        m_pCubeArray[BACK][0][m_dim-1]        = pCube;
        m_pCubeArray[LEFT][0][0]            = pCube;

        // top back right
        pCube = MakeRandCube(TOP, 0, m_dim-1);
        m_pCubePool->Add(pCube);
        m_pCubeArray[TOP][0][m_dim-1]         = pCube;
        m_pCubeArray[BACK][0][0]            = pCube;
        m_pCubeArray[RIGHT][0][m_dim-1]       = pCube;

        // bottom front left
        pCube = MakeRandCube(BOTTOM, 0, 0);
        m_pCubePool->Add(pCube);
        m_pCubeArray[BOTTOM][0][0]          = pCube;
        m_pCubeArray[FRONT][m_dim-1][0]       = pCube;
        m_pCubeArray[LEFT][m_dim-1][m_dim-1]    = pCube;

        // bottom front right
        pCube = MakeRandCube(BOTTOM, 0, m_dim-1);
        m_pCubePool->Add(pCube);
        m_pCubeArray[BOTTOM][0][m_dim-1]      = pCube;
        m_pCubeArray[FRONT][m_dim-1][m_dim-1]   = pCube;
        m_pCubeArray[RIGHT][m_dim-1][0]       = pCube;

        // bottom back left
        pCube = MakeRandCube(BOTTOM, m_dim-1, 0);
        m_pCubePool->Add(pCube);
        m_pCubeArray[BOTTOM][m_dim-1][0]      = pCube;
        m_pCubeArray[BACK][m_dim-1][m_dim-1]    = pCube;
        m_pCubeArray[LEFT][m_dim-1][0]        = pCube;

        // bottom back right
        pCube = MakeRandCube(BOTTOM, m_dim-1, m_dim-1);
        m_pCubePool->Add(pCube);
        m_pCubeArray[BOTTOM][m_dim-1][m_dim-1]  = pCube;
        m_pCubeArray[BACK][m_dim-1][0]        = pCube;
        m_pCubeArray[RIGHT][m_dim-1][m_dim-1]   = pCube;
    }

    ASSERT(m_pCubePool->size() == m_numCubes);

    // choose a start and end to kick off the game
    ChooseStartAndEnd();
}

World::~World()
{
    for (UINT face = 0; face < NUM_FACES; face++)
    {
        for (UINT x = 0; x < m_dim; x++)
        {
            for (UINT y = 0; y < m_dim; y++)
            {
                m_pCubeArray[face][y][x] = NULL;
            }
        }
    }

    delete [] m_pNumColorCubes;

    // dynamic multi-dimensional array
    for (UINT face = 0; face < NUM_FACES; face++)
    {
        for (UINT row = 0; row < m_dim; row++)
        {
            delete [] m_pCubeArray[face][row];
        }
        delete [] m_pCubeArray[face];
    }
    delete [] m_pCubeArray;

    delete m_pBigCube;
    delete m_pCubePool;
}

void World::Init()
{
        //TODO: these buffers should be a global init, and even m_soundHit/m_soundDead can be global
        ALuint buffer;

        buffer = alutCreateBufferFromFile("res\\CubeSelect.wav");
        alGenSources(1, &m_soundSelect);
        alSourcei(m_soundSelect, AL_BUFFER, buffer);
        alSourcei(m_soundSelect, AL_LOOPING, AL_FALSE);

        buffer = alutCreateBufferFromFile("res\\BadSelect.wav");
        alGenSources(1, &m_soundBadSelect);
        alSourcei(m_soundBadSelect, AL_BUFFER, buffer);
        alSourcei(m_soundBadSelect, AL_LOOPING, AL_FALSE);

        buffer = alutCreateBufferFromFile("res\\CubeSwap.wav");
        alGenSources(1, &m_soundSwap);
        alSourcei(m_soundSwap, AL_BUFFER, buffer);
        alSourcei(m_soundSwap, AL_LOOPING, AL_FALSE);

        buffer = alutCreateBufferFromFile("res\\PathClear.wav");
        alGenSources(1, &m_soundPathClear);
        alSourcei(m_soundPathClear, AL_BUFFER, buffer);
        alSourcei(m_soundPathClear, AL_LOOPING, AL_FALSE);

        buffer = alutCreateBufferFromFile("res\\Death.wav");
        alGenSources(1, &m_soundDead);
        alSourcei(m_soundDead, AL_BUFFER, buffer);
        alSourcei(m_soundDead, AL_LOOPING, AL_FALSE);

        buffer = alutCreateBufferFromFile("res\\Win.wav");
        alGenSources(1, &m_soundWin);
        alSourcei(m_soundWin, AL_BUFFER, buffer);
        alSourcei(m_soundWin, AL_LOOPING, AL_FALSE);
}

CCube* World::MakeRandCube(CUBE_FACE face, int row, int col)
{
    float x, y, z = 0.f;    // each cube's position in world
    int dim = m_dim;        // dim needs to be a signed int
    D3DCOLORVALUE color;

    float separation = 1.1f;    // percentage of scale for separation

    // calculate each cube's world coordinates
    switch (face)
    {
        case TOP:
            y = 0.f;
            x = col * m_scale;
            z = (dim-1-row) * m_scale;
            break;
        case BOTTOM:
            y = (0-(dim-1)) * m_scale;
            x = col * m_scale;
            z = row * m_scale;
            break;
        case FRONT:
            z = 0.f;
            x = col * m_scale;
            y = (0-row) * m_scale;
            break;
        case BACK:
            z = (dim-1) * m_scale;
            x = (dim-1-col) * m_scale;
            y = (0-row) * m_scale;
            break;
        case LEFT:
            x = 0.f;
            y = (0-row) * m_scale;
            z = (dim-1-col) * m_scale;
            break;
        case RIGHT:
            x = (dim-1) * m_scale;
            y = (0-row) * m_scale;
            z = col * m_scale;
            break;
        default:
            ASSERT(!"Shouldn't get here");
            break;
    }

    x*=separation;
    y*=separation;
    z*=separation;

    // rebase the "world cube" so the center is (0,0,0)
    float halfWorld = (dim*m_scale*separation)/2.0f;
    // NOTE: position specifies center of cube, so also account for that
    halfWorld -= m_scale/2.0f;

    x -= halfWorld;
    y += halfWorld;
    z -= halfWorld;

    // calculate random color
    UINT randColor = rand() % m_numColors;
    ASSERT(randColor >= 0);
    ASSERT(randColor < m_numColors);

    // make sure there are an evenly distributed number of colors
    while (m_pNumColorCubes[randColor] >= m_maxColorCubes)
    {
        randColor = rand() % m_numColors;
    }

    m_pNumColorCubes[randColor]++;  // adding one more cube of some color

    switch (randColor)
    {
        case C_RED:
            color = RED;
            break;
        case C_BLUE:
            color = BLUE;
            break;
        case C_PURPLE:
            color = PURPLE;
            break;
        case C_GREEN:
            color = GREEN;
            break;        
        case C_ORANGE:
            color = ORANGE;
            break;        
        default:
            ASSERT(!"Shouldn't get here");
            break;
    }

    CCube* pCube = new CCube(true, true, btVector3(x,y,z), m_scale, color, (CUBE_COLOR)randColor, COL_PARTICLE, COL_EVERYTHING);

    // Make cube immovable
    PhysicsData* pPhysData = pCube->GetPhysicsData();
    ASSERT(pPhysData);
    pPhysData->UnregisterPhysics();
    pPhysData->m_pBtRigidBody->setMassProps(0, btVector3(0,0,0));
    pPhysData->m_pBtRigidBody->clearForces();
    pPhysData->m_pBtRigidBody->activate();
    pPhysData->RegisterPhysics();

    return pCube;
}

CCube* World::ClosestCube(const btCollisionWorld::AllHitsRayResultCallback& rayCallback)
{
    // this is an awful naiive sort

    ObjectData* pObjectData = NULL;
    btScalar objectDist;
    btVector3 camPos = btVector3(m_pCamera->m_pos.x, m_pCamera->m_pos.y, m_pCamera->m_pos.z);
    CCube* pCube = NULL;

    for (int i = 0; i < rayCallback.m_collisionObjects.size(); i++)
    {
        if(reinterpret_cast<ObjectData*>(rayCallback.m_collisionObjects[i]->getUserPointer())->GetPhysicsData()->m_InitPhysicsData.CollisionGroup & COL_PARTICLE)
        {
            if (pObjectData)
            {
                if ((camPos - rayCallback.m_hitPointWorld[i]).length() < objectDist)
                {
                    pObjectData = reinterpret_cast<ObjectData*>(rayCallback.m_collisionObjects[i]->getUserPointer());
                    objectDist = (camPos - rayCallback.m_hitPointWorld[i]).length();
                }
            }
            else
            {
                pObjectData = reinterpret_cast<ObjectData*>(rayCallback.m_collisionObjects[i]->getUserPointer());
                objectDist = (camPos - rayCallback.m_hitPointWorld[i]).length();
            }
        }
    }

    if (pObjectData)
    {
        pCube = reinterpret_cast<CCube*>(pObjectData);
    }
    return pCube;
}

void World::Update(const float& dt)
{
    // init ray picking
    m_rayFrom = m_pCamera->m_pos;
    m_rayTo = m_pCamera->GetPickRay(m_cursorCoords.x(), m_cursorCoords.y());

    btVector3 btRayFrom = btVector3(m_rayFrom.x, m_rayFrom.y, m_rayFrom.z);
    btVector3 btRayTo = btVector3(m_rayTo.x, m_rayTo.y, m_rayTo.z);

    // Update the cursor
    m_cursorCoords.setX(m_cursorCoords.x() + g_pInput->MouseDX());
    m_cursorCoords.setY(m_cursorCoords.y() + g_pInput->MouseDY());
    if (m_cursorCoords.x() > SCREEN_WIDTH)
    {
        m_cursorCoords.setX(SCREEN_WIDTH);
    }
    if (m_cursorCoords.x() < 0)
    {
        m_cursorCoords.setX(0);
    }
    if (m_cursorCoords.y() > SCREEN_HEIGHT)
    {
        m_cursorCoords.setY(SCREEN_HEIGHT);
    }
    if (m_cursorCoords.y() < 0)
    {
        m_cursorCoords.setY(0);
    }

    // update eye candy
    if (m_pulseFactor > m_maxPulseFactor ||
        m_pulseFactor < m_minPulseFactor)
    {
        m_pulseInc = -m_pulseInc;   // reverse pulse direction
    }
    m_pulseFactor += m_pulseInc;

    // update game logic based on game state
    switch (ObjectManager::gameState)
    {
        case PLAYING:
            // handle input
            if (g_pInput->MouseButtonPressed(SHOOT))    // fire pick ray
            {
                btCollisionWorld::AllHitsRayResultCallback rayCallback(btRayFrom,btRayTo);
                g_pBtDynamicsWorld->rayTest(btRayFrom, btRayTo, rayCallback);
                if (rayCallback.hasHit())
                {
                    //rayCallback.m_collisionObjects.quickSort();   // I don't understand how to use this...

                    CCube* pCube = ClosestCube(rayCallback);

                    if (pCube)
                    {
                        // do something with selected cube
                        SelectCube(pCube);
                        break;
                    }
                }
            }
            else if (g_pInput->MouseButtonReleased(SHOOT))
            {
                // ?
            }
            else if (g_pInput->MouseButtonDown(SHOOT))
            {
                // Maybe instead of clicking twice to switch 2 cubes, just click and drag?
            }

            // pulsate cubes
            if (m_pStartCube)
            {
                m_pStartCube->m_scale = m_scale*m_pulseFactor;
            }
            if (m_pEndCube)
            {
                m_pEndCube->m_scale = m_scale*m_pulseFactor;
            }
            break;

        case GAME_WON:
            m_pBigCube->m_scale = (m_dim-2)*m_scale*m_pulseFactor;
            break;

        default:
            // nothing to do
            break;
    }

    m_pBigCube->Update(dt);
    m_pCubePool->Update(dt);
}

bool World::CubesAreAdjacent(CCube* pCubeA, CCube* pCubeB)
{
    ASSERT(pCubeA != NULL);
    ASSERT(pCubeB != NULL);
    if (!pCubeA || !pCubeB)
    {
        return false;
    }

    for (UINT face = 0; face < NUM_FACES; face++)
    {
        for (UINT x = 0; x < m_dim; x++)
        {
            for (UINT y = 0; y < m_dim; y++)
            {
                if (pCubeA == m_pCubeArray[face][y][x])
                {
                    if (x > 0 && m_pCubeArray[face][y][x-1] == pCubeB)
                    {
                        return true;
                    }
                    if (x < m_dim-1 && m_pCubeArray[face][y][x+1] == pCubeB)
                    {
                        return true;
                    }
                    if (y > 0 && m_pCubeArray[face][y-1][x] == pCubeB)
                    {
                        return true;
                    }
                    if (y < m_dim-1 && m_pCubeArray[face][y+1][x] == pCubeB)
                    {
                        return true;
                    }
                }
            }
        }
    }

    return false;
}

void World::SwapCubes(CCube* pCubeA, CCube* pCubeB)
{
    // NOTE: function ONLY swaps colors

    ASSERT(pCubeA != NULL);
    ASSERT(pCubeB != NULL);

    D3DCOLORVALUE tempColor = pCubeA->m_color;
    CUBE_COLOR tempColorEnum = pCubeA->m_colorEnum;
    pCubeA->m_color = pCubeB->m_color;
    pCubeA->m_colorEnum = pCubeB->m_colorEnum;
    pCubeB->m_color = tempColor;
    pCubeB->m_colorEnum = tempColorEnum;

    // play noise
    alSourcePlay(m_soundSwap);

    // each time cubes are swapped, check for path completion
    CheckPath();
}

void World::HighlightCube(CCube* pCube)
{
    switch (pCube->m_colorEnum)
    {
        case C_RED:
            pCube->m_color = RED_1;
            break;
        case C_BLUE:
            pCube->m_color = BLUE_1;
            break;
        case C_PURPLE:
            pCube->m_color = PURPLE_1;
            break;
        case C_GREEN:
            pCube->m_color = GREEN_1;
            break;
        case C_ORANGE:
            pCube->m_color = ORANGE_1;
            break;
        default:
            ASSERT(!"Shouldn't get here");
            break;
    }
}

void World::UnHighlightCube(CCube* pCube)
{
    switch (pCube->m_colorEnum)
    {
        case C_RED:
            pCube->m_color = RED;
            break;
        case C_BLUE:
            pCube->m_color = BLUE;
            break;
        case C_PURPLE:
            pCube->m_color = PURPLE;
            break;
        case C_GREEN:
            pCube->m_color = GREEN;
            break;
        case C_ORANGE:
            pCube->m_color = ORANGE;
            break;
        default:
            ASSERT(!"Shouldn't get here");
            break;
    }
}

void World::SelectCube(CCube* pCube)
{
    ASSERT(pCube != NULL);

    if (pCube == m_pSelectedCube)
    {
        UnHighlightCube(m_pSelectedCube);
        m_pSelectedCube = NULL;
    }
    else if (m_pSelectedCube == NULL)
    {
        m_pSelectedCube = pCube;
        // TODO: emissive?
        HighlightCube(m_pSelectedCube);

        // play noise
        alSourcePlay(m_soundSelect);
    }
    else if (CubesAreAdjacent(m_pSelectedCube, pCube))
    {
        UnHighlightCube(m_pSelectedCube);
        // TODO: swapping animation
        SwapCubes(m_pSelectedCube, pCube);  // plays noise
        m_pSelectedCube = NULL;
    }
    else
    {
        // Cubes were selected that were not adjacent
        UnHighlightCube(m_pSelectedCube);
        m_pSelectedCube = NULL;

        // play noise
        alSourcePlay(m_soundBadSelect);
    }
}

UINT World::PathLength(int startFace, int startRow, int startCol, int endFace, int endRow, int endCol)
{
    // this is going to be really gross...

    ASSERT(!(startFace == endFace && startRow == endRow && startCol == endCol));

    UINT length = 1;    // account for the start position

    if (startFace != endFace)
    {
        // if they're opposite faces
        if (startFace == TOP && endFace == BOTTOM ||
            endFace == TOP && startFace == BOTTOM)
        {
            length += m_dim*2;
        }
        else if (startFace == LEFT && endFace == RIGHT ||
                 endFace == LEFT && startFace == RIGHT)
        {
            length += m_dim*2;
        }

        else if (startFace == FRONT && endFace == BACK ||
                 endFace == FRONT && startFace == BACK)
        {
            length += m_dim*2;
        }

        // if they're adjacent faces
        else
        {
            length += m_dim;
        }
    }

    // if different rows
    if (startRow > endRow)
    {
        length += startRow - endRow;
    }
    else if (endRow > startRow)
    {
        length += endRow - startRow;
    }

    // if different columns
    if (startCol > endCol)
    {
        length += startCol - endCol;
    }
    else if (endCol > startCol)
    {
        length += endCol - startCol;
    }

    return length;
}

void World::ChooseStartAndEnd()
{
    // determine longest path that can be made with any color
    UINT maxPathLength = 0;
    for (UINT i = 0; i < m_numColors; i++)
    {
        if (m_pNumColorCubes[i] > maxPathLength)
        {
            maxPathLength = m_pNumColorCubes[i];
        }
    }

    // choose the start cube
    UINT startFace  = rand() % NUM_FACES;
    UINT startRow   = rand() % m_dim;
    UINT startCol   = rand() % m_dim;

    // make sure there's a cube at the array location
    while (m_pCubeArray[startFace][startRow][startCol] == NULL)
    {
        startFace   = rand() % NUM_FACES;
        startRow    = rand() % m_dim;
        startCol    = rand() % m_dim;
    }

    m_pStartCube = m_pCubeArray[startFace][startRow][startCol];

    // choose the end cube
    UINT endFace    = rand() % NUM_FACES;
    UINT endRow     = rand() % m_dim;
    UINT endCol     = rand() % m_dim;

    // make sure there's a cube at the array location
    // and that the colors are not the same
    // and that the start is not the same as the end point
    // and that the distance is <= num colors left for a given color
    // TODO: and that there is an available solution giving the missing cubes!
    while (m_pCubeArray[endFace][endRow][endCol] == NULL || 
           m_pCubeArray[endFace][endRow][endCol]->m_colorEnum == m_pStartCube->m_colorEnum ||
           (startFace == endFace && startRow == endRow && startCol == endCol) ||
           maxPathLength < PathLength(startFace, startRow, startCol, endFace, endRow, endCol))
    {
        endFace     = rand() % NUM_FACES;
        endRow      = rand() % m_dim;
        endCol      = rand() % m_dim;
    }

    m_pEndCube = m_pCubeArray[endFace][endRow][endCol];

    // each time a new start and end are generated, check for existing path
    CheckPath();
}

void World::PopCube(CCube* pCube)
{
    ASSERT(pCube);

    UINT faceFound = 6;
    // remove from m_pCubeArray
    for (UINT face = 0; face < NUM_FACES; face++)
    {
        for (UINT x = 0; x < m_dim; x++)
        {
            for (UINT y = 0; y < m_dim; y++)
            {
                if (pCube == m_pCubeArray[face][y][x])
                {
                    m_pCubeArray[face][y][x] = NULL;
                    faceFound = face;
                }
            }
        }
    }

    btVector3 velocity = btVector3(0,0,0);
    switch (faceFound)
    {
        case TOP:
            velocity = btVector3(((float)(rand()%20000-10000))/500,
                                 80,
                                 ((float)(rand()%20000-10000))/500);
            break;
        case BOTTOM:
            velocity = btVector3(((float)(rand()%20000-10000))/1000,
                                 -50,
                                 ((float)(rand()%20000-10000))/1000);
            break;
        case LEFT:
            velocity = btVector3(-50,
                                 ((float)(rand()%20000-10000))/1000,
                                 ((float)(rand()%20000-10000))/1000);
            break;
        case RIGHT:
            velocity = btVector3(50,
                                 ((float)(rand()%20000-10000))/1000,
                                 ((float)(rand()%20000-10000))/1000);
            break;
        case FRONT:
            velocity = btVector3(((float)(rand()%20000-10000))/1000,
                                 ((float)(rand()%20000-10000))/1000,
                                 -50);
            break;
        case BACK:
            velocity = btVector3(((float)(rand()%20000-10000))/1000,
                                 ((float)(rand()%20000-10000))/1000,
                                 50);
            break;
        default:
            ASSERT(!"Shouldn't get here");
            break;
    }

    // pop animation
    pCube->m_color = GREY;

    PhysicsData* pPhysData = pCube->GetPhysicsData();
    ASSERT(pPhysData);
    pPhysData->UnregisterPhysics();
    pPhysData->m_pBtRigidBody->setMassProps(pCube->m_scale * pCube->m_scale, btVector3(0,0,0));

    btTransform t;
    t.setRotation(btQuaternion(0,0,0,1));
    t.setOrigin(pCube->m_pos);

    pPhysData->m_pBtRigidBody->setCenterOfMassTransform(t);
    pPhysData->m_pBtRigidBody->setLinearVelocity(velocity);
    pPhysData->m_pBtRigidBody->setAngularVelocity(btVector3(0.0f,0.0f,0.0f));

    pPhysData->m_pBtRigidBody->activate();
    pPhysData->RegisterPhysics();

    // decrement m_pNumColorCubes
    ASSERT(m_pNumColorCubes[pCube->m_colorEnum] > 0);
    --m_pNumColorCubes[pCube->m_colorEnum];
}

bool World::CheckPathRecursive(CCube* pCube, bool restrictColor)
{
    ASSERT(pCube);
    if (restrictColor && m_pStartCube)
    {
        ASSERT(pCube->m_colorEnum == m_pStartCube->m_colorEnum);
    }

    bool pathFound = false;
    if (!m_pPathPool->Contains(pCube))
    {
        m_pPathPool->Add(pCube);
        if (pCube == m_pEndCube)
        {
            pathFound = true;
        }

        CCube* pTestCube;

        // find the face, row and col for the current cube
        for (UINT face = 0; face < NUM_FACES; face++)
        {
            for (UINT row = 0; row < m_dim; row++)
            {
                for (UINT col = 0; col < m_dim; col++)
                {
                    if (pCube == m_pCubeArray[face][row][col])
                    {
                        if (col > 0)
                        {
                            pTestCube = m_pCubeArray[face][row][col-1];
                            if (pTestCube && (restrictColor == false || pTestCube->m_colorEnum == m_pStartCube->m_colorEnum))
                            {
                                if (CheckPathRecursive(pTestCube, restrictColor))
                                {
                                    pathFound = true;
                                }
                            }
                        }
                        if (col < m_dim-1)
                        {
                            pTestCube = m_pCubeArray[face][row][col+1];
                            if (pTestCube && (restrictColor == false || pTestCube->m_colorEnum == m_pStartCube->m_colorEnum))
                            {
                                if (CheckPathRecursive(pTestCube, restrictColor))
                                {
                                    pathFound = true;
                                }
                            }
                        }
                        if (row > 0)
                        {
                            pTestCube = m_pCubeArray[face][row-1][col];
                            if (pTestCube && (restrictColor == false || pTestCube->m_colorEnum == m_pStartCube->m_colorEnum))
                            {
                                if (CheckPathRecursive(pTestCube, restrictColor))
                                {
                                    pathFound = true;
                                }
                            }
                        }
                        if (row < m_dim-1)
                        {
                            pTestCube = m_pCubeArray[face][row+1][col];
                            if (pTestCube && (restrictColor == false || pTestCube->m_colorEnum == m_pStartCube->m_colorEnum))
                            {
                                if (CheckPathRecursive(pTestCube, restrictColor))
                                {
                                    pathFound = true;
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    return pathFound;
}

void World::GameOver()
{
    // Set the game state
    ObjectManager::gameState = GAME_OVER;

    // Make all cubes movable
    Pool<CCube*>::iterator it;
    for (it = m_pCubePool->begin(); it != m_pCubePool->end(); ++it)
    {
        PhysicsData* pPhysData = (*it)->GetPhysicsData();
        ASSERT(pPhysData);
        pPhysData->UnregisterPhysics();
        pPhysData->m_pBtRigidBody->setMassProps((*it)->m_scale * (*it)->m_scale, btVector3(0,0,0));
        pPhysData->m_pBtRigidBody->activate();
        pPhysData->RegisterPhysics();
    }

    PhysicsData* pPhysData = m_pBigCube->GetPhysicsData();
    ASSERT(pPhysData);
    pPhysData->UnregisterPhysics();
    pPhysData->m_pBtRigidBody->setMassProps(m_pBigCube->m_scale * m_pBigCube->m_scale, btVector3(0,0,0));
    pPhysData->m_pBtRigidBody->activate();
    pPhysData->RegisterPhysics();

    m_pBigCube->m_color = BLACK;

    // play noise
    alSourcePlay(m_soundDead);
}

void World::GameWon()
{
    // Set the game state
    ObjectManager::gameState = GAME_WON;

    m_pBigCube->m_color = WHITE;

    // play noise
    alSourcePlay(m_soundWin);
}

void World::CheckPath()
{
    ASSERT(m_pPathPool->size() == 0);

    // if start connects to end using strictly adjacent cubes
    bool pathFound = CheckPathRecursive(m_pStartCube, true);

    // if path is found, pop all the cubes in that path
    if (pathFound)
    {
        Pool<CCube*>::iterator it;
        for (it = m_pPathPool->begin(); it != m_pPathPool->end(); ++it)
        {
            PopCube(*it);
        }
    }

    // clear the path pool; it should be new each time we call CheckPath
    m_pPathPool->clear();

    // if there is only one cube of the color that was just cleared left, also pop that cube
    CCube* pTestCube;
    
    if (m_pNumColorCubes[m_pStartCube->m_colorEnum] == 1)
    {
        for (UINT face = 0; face < NUM_FACES; face++)
        {
            for (UINT x = 0; x < m_dim; x++)
            {
                for (UINT y = 0; y < m_dim; y++)
                {
                    pTestCube = m_pCubeArray[face][y][x];
                    if (pTestCube)
                    {
                        PopCube(pTestCube);
                    }
                }
            }
        }
    }


    // choose any valid cube and see if it connects to all remaining cubes
    bool found = false;

    UINT numCubesLeft = 0;
    for (UINT colorEnum = 0; colorEnum < m_numColors; colorEnum++)
    {
        numCubesLeft += m_pNumColorCubes[colorEnum];
    }

    if (numCubesLeft == 0)
    {
        GameWon();
    }
    else
    {
        for (UINT face = 0; face < NUM_FACES, !found; face++)
        {
            for (UINT x = 0; x < m_dim, !found; x++)
            {
                for (UINT y = 0; y < m_dim, !found; y++)
                {
                    if (m_pCubeArray[face][y][x])
                    {
                        found = true;   // found a valid cube

                        CheckPathRecursive(m_pCubeArray[face][y][x], false); 

                        if (m_pPathPool->size() != numCubesLeft)
                        {
                            // some cubes have lost connection, game over
                            GameOver();
                        }
                        else if (m_pPathPool->size() == 0)
                        {
                            GameWon();
                        }
                        else if (m_pPathPool->size() == 1)
                        {
                            PopCube(m_pCubeArray[face][y][x]);
                            GameWon();
                        }

                        // if there is only one color left and they're all connecting, you win!
                        for (UINT colorEnum = 0; colorEnum < m_numColors; colorEnum++)
                        {
                            if (m_pNumColorCubes[colorEnum] == numCubesLeft &&
                                numCubesLeft == m_pPathPool->size())
                            {
                                Pool<CCube*>::iterator it;
                                for (it = m_pPathPool->begin(); it != m_pPathPool->end(); ++it)
                                {
                                    PopCube(*it);
                                }
                                GameWon();
                            }
                        }

                        m_pPathPool->clear();
                    }
                }
            }

            ASSERT(found == true || numCubesLeft == 0);  // make sure we found at least one valid cube if it exists
        }
    }

    // otherwise, if path completed and we're still playing, choose new start and end
    if (pathFound && ObjectManager::gameState == PLAYING)
    {
        // play noise
        alSourcePlay(m_soundPathClear);

        ChooseStartAndEnd();
    }
}

void World::Draw(D3DXMATRIX matViewProj)
{
    m_pBigCube->Draw(matViewProj);
    m_pCubePool->Draw(matViewProj);
}
