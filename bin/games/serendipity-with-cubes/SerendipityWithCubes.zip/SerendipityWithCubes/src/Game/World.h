
#pragma once

#include "Common.h"
#include "Cube.h"
#include "Pool.h"
#include "Camera.h"
#include "Input.h"

enum CUBE_COLOR
{
    C_RED       = 0,
    C_BLUE      = 1,
    C_GREEN     = 2,
    C_PURPLE    = 3,
    C_ORANGE    = 4,
    MAX_COLORS  = 5,
};

enum CUBE_FACE
{
    TOP         = 0,
    BOTTOM      = 1,
    FRONT       = 2,
    BACK        = 3,
    LEFT        = 4,
    RIGHT       = 5,
    NUM_FACES   = 6,
};

class CCube : public Cube
{
public:
    CCube(bool render,       // TODO: add orientation
          bool physics, 
          const btVector3& pos, 
          float scale,       // TODO: make scale a width, height and depth
          const D3DCOLORVALUE& color,
          const CUBE_COLOR& colorEnum,
          short collisionGroup = COL_PARTICLE,
          short collisionMask = COL_EVERYTHING,
          const btVector3& vel = btVector3(0,0,0)) :
    m_colorEnum(colorEnum), Cube(render, physics, pos, scale, color, collisionGroup, collisionMask, vel){};
    
    ~CCube(){};

    CUBE_COLOR m_colorEnum;
};

class World{

public:

    World(IDirect3DDevice9* pDevice, Camera* pCamera, UINT dim, UINT numColors, float scale);
    ~World();

    static void Init();
    static void Destroy(){};

    void SetCamera(Camera* pCamera);
    void Update(const float& timeDiff);      // Time in seconds
    void Draw(D3DXMATRIX  matViewProj);
    ULONG GetNumCubes();
    Pool<CCube*>* GetCubePool();
    void OnLostDevice();
    void OnResetDevice();

protected:

    World():m_dim(0),m_numColors(0){};

private:

    IDirect3DDevice9*   m_pDevice;
    Camera*             m_pCamera;
    const UINT          m_dim;
    float               m_scale;
    btVector3           m_pos;
    btVector3           m_rot;
    Pool<CCube*>*       m_pCubePool;
    ULONG               m_numCubes;
    CCube*              m_pSelectedCube;
    CCube*              m_pStartCube;
    CCube*              m_pEndCube;
    Pool<CCube*>*       m_pPathPool;

    btVector3   m_cursorCoords;   // The cursor is a 2d mouse position. The screen center is (0,0,0)
    D3DXVECTOR3 m_rayFrom;
    D3DXVECTOR3 m_rayTo;
    btVector3   m_pickPos;
    btScalar    m_pickDist;

    // eye candy
    float       m_pulseInc;
    float       m_pulseFactor;
    float       m_maxPulseFactor;
    float       m_minPulseFactor;

    // sounds
    static ALuint m_soundSelect;
    static ALuint m_soundBadSelect;
    static ALuint m_soundSwap;
    static ALuint m_soundPathClear;
    static ALuint m_soundDead;
    static ALuint m_soundWin;

    Cube* m_pBigCube;

    // NUM_FACES of m_dim x m_dim cubes, edges shared.
    // dynamic 3D array of WorldCube
    CCube**** m_pCubeArray;

/*
    LAYOUT:
    _______
                -----------------
                |           DIM |
                |             . |
                |             | |
                |      Back   | |
                |             | |
                | DIM <------ 0 |
-------------------------------------------------
| DIM <------ 0 | 0 ------> DIM | DIM           |
|             | | |             | |             |
|             | | |             | |             |
|     Left    | | |    Top      | |    Right    |
|             . | .             | |             |
|           DIM | DIM           | 0 ------> DIM |
-------------------------------------------------
              / | 0 ------> DIM |
             /  | |             |
            /   | |             |
           /    | |   Front     |
 (-.5,.5,-.5)   | |             |
                | DIM           |
                -----------------
                | 0 ------> DIM |
                | |             |
                | |             |
                | |  Bottom     |
                | |             |
                | DIM           |
                -----------------
*/

    // for tracking what colors to use
    const UINT m_numColors;
    UINT m_maxColorCubes;
    UINT* m_pNumColorCubes;

    CCube* MakeRandCube(CUBE_FACE face, int row, int col);
    CCube* ClosestCube(const btCollisionWorld::AllHitsRayResultCallback& rayCallback);
    void SelectCube(CCube* pCube);
    void HighlightCube(CCube* pCube);
    void UnHighlightCube(CCube* pCube);
    bool CubesAreAdjacent(CCube* pCubeA, CCube* pCubeB);
    void SwapCubes(CCube* pCubeA, CCube* pCubeB);
    void ChooseStartAndEnd();
    void CheckPath();
    bool CheckPathRecursive(CCube* pCube, bool restrictColor);
    UINT PathLength(int startFace, int startRow, int startCol, int endFace, int endRow, int endCol);
    void PopCube(CCube* pCube);
    void GameOver();
    void GameWon();

};    
/*******************************************************************************
// inline functions
*******************************************************************************/
inline void World::SetCamera(Camera* pCamera)
{
    m_pCamera = pCamera;
}

inline void World::OnLostDevice()
{
    if (m_pCubePool)
    {
        Pool<CCube*>::const_iterator i;
        for (i = m_pCubePool->begin(); i != m_pCubePool->end(); ++i)
        {
            (*i)->OnLostDevice();
        }
    }
    if (m_pBigCube)
    {
        m_pBigCube->OnLostDevice();
    }
}

inline void World::OnResetDevice()
{
    if (m_pCubePool)
    {
        Pool<CCube*>::const_iterator i;
        for (i = m_pCubePool->begin(); i != m_pCubePool->end(); ++i)
        {
            (*i)->OnResetDevice();
        }
    }
    if (m_pBigCube)
    {
        m_pBigCube->OnResetDevice();
    }
}

inline ULONG World::GetNumCubes()
{
    return m_numCubes;
}

inline Pool<CCube*>* World::GetCubePool()
{
    return m_pCubePool;
}
