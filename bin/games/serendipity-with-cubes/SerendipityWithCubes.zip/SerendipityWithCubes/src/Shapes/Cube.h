
#pragma once

#include "Common.h"
#include "ObjectData.h"

class Cube : public ObjectData
{
public:

    Cube(bool render,       // TODO: add orientation
         bool physics, 
         const btVector3& pos, 
         float scale,       // TODO: make scale a width, height and depth
         const D3DCOLORVALUE& color, 
         short collisionGroup = COL_PARTICLE,
         short collisionMask = COL_EVERYTHING,
         const btVector3& vel = btVector3(0,0,0));
    ~Cube();

    static void Init(IDirect3DDevice9* pDevice, btDiscreteDynamicsWorld* pWorld);
    static void OnLostDevice();
    static void OnResetDevice();
    static void Destroy();
    static RenderData* GetRenderData();

protected:
    Cube(){};   // Don't call this


private:

    // Render Data
    static Vertex CubeVertices[];
    static short CubeIndices[];
    static InitRenderData CubeRenderData;
    static RenderData* pRenderData;

    // Physics Data
    static btDiscreteDynamicsWorld* g_pBtDynamicsWorld;
};
