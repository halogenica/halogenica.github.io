
#include "Plane.h"
                       
btDiscreteDynamicsWorld* Plane::g_pBtDynamicsWorld = NULL;
RenderData* Plane::pRenderData = NULL;

/***************************************************************
* Static Data
***************************************************************/
Vertex Plane::PlaneVertices[] =
{
    {{-0.5f, 0.0f, -0.5f}, {0, 1, 0}, WHITE},  //0 - left lower back
    {{-0.5f, 0.0f, +0.5f}, {0, 1, 0}, RED},    //1 - left upper back
    {{+0.5f, 0.0f, -0.5f}, {0, 1, 0}, GREEN},  //2 - right upper back
    {{+0.5f, 0.0f, +0.5f}, {0, 1, 0}, BLUE}    //3 - right lower back
};

short Plane::PlaneIndices[] =
{
    0, 1, 3,
    0, 3, 2,
};

InitRenderData Plane::PlaneRenderData =
{
    VertexDeclElements,
    D3DPT_TRIANGLELIST,
    PlaneVertices,
    PlaneIndices,
    4,
    2,
    3 * 2,
    "BasicTech",
};

void Plane::Init(IDirect3DDevice9* pDevice, btDiscreteDynamicsWorld* pWorld)
{
    pRenderData = new RenderData(pDevice, PlaneRenderData);
    Plane::g_pBtDynamicsWorld = pWorld;
}

void Plane::OnLostDevice()
{
    ASSERT(pRenderData);
    pRenderData->OnLostDevice();
}

void Plane::OnResetDevice()
{
    ASSERT(pRenderData);
    pRenderData->OnResetDevice();
}

void Plane::Destroy()
{
    ASSERT(pRenderData);
    delete pRenderData;
}

RenderData* Plane::GetRenderData()
{
    return pRenderData;
}


/***************************************************************
* Instance Data
***************************************************************/

Plane::Plane(bool render,
             bool physics,
             const btVector3& pos, 
             float scale,
             const D3DCOLORVALUE& color,
             short collisionGroup,
             short collisionMask,
             const btVector3& vel) :
                 ObjectData(pos, btQuaternion(0,0,0,1), scale, color, collisionGroup, collisionMask, vel)
{
    ASSERT(Plane::g_pBtDynamicsWorld != NULL);  // Make sure Plane::Init() was called

    if (render)
    {
        SetRenderData(pRenderData);
    }

    if (physics)
    {
        InitPhysicsData planePhysicsData =
        {
            new btStaticPlaneShape(btVector3(0,1,0), 1),    // TODO: this represents an infinite plane
            collisionGroup,
            collisionMask,
            0,                                              // TODO: infinite planes are immovable (0 mass)
            m_pos,
            m_rot,
            vel
        };
        SetPhysicsData(new PhysicsData(g_pBtDynamicsWorld, planePhysicsData));
    }
}

Plane::~Plane()
{
    if (m_pPhysicsData)
    {
        delete m_pPhysicsData;
    }
}
