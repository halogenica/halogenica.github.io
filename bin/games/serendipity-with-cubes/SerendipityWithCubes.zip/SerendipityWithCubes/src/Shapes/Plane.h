
#pragma once

#include "Common.h"
#include "ObjectData.h"

class Plane : public ObjectData
{
public:

    Plane(bool render,      // TODO: add orientation
          bool physics, 
          const btVector3& pos, 
          float scale,      // TODO: make scale a width and height
          const D3DCOLORVALUE& color, 
          short collisionGroup = COL_NOTHING,
          short collisionMask = COL_NOTHING,
          const btVector3& vel = btVector3(0,0,0));
    ~Plane();

    static void Init(IDirect3DDevice9* pDevice, btDiscreteDynamicsWorld* pWorld);
    static void OnLostDevice();
    static void OnResetDevice();
    static void Destroy();
    static RenderData* GetRenderData();

protected:
    Plane(){};  // Don't call this

private:

    // Render Data
    static Vertex PlaneVertices[];
    static short PlaneIndices[];
    static InitRenderData PlaneRenderData;
    static RenderData* pRenderData;

    // Physics Data
    static btDiscreteDynamicsWorld* g_pBtDynamicsWorld;
};
