
#include "Cube.h"
                       
btDiscreteDynamicsWorld* Cube::g_pBtDynamicsWorld = NULL;
RenderData* Cube::pRenderData = NULL;

/***************************************************************
* Static Data
***************************************************************/
Vertex Cube::CubeVertices[] =
{
    {{-0.5f, -0.5f, -0.5f}, { 0,  0, -1}, WHITE},   //0  - left lower back - back
    {{-0.5f, -0.5f, -0.5f}, { 0, -1,  0}, WHITE},   //1  - left lower back - lower
    {{-0.5f, -0.5f, -0.5f}, {-1,  0,  0}, WHITE},   //2  - left lower back - left

    {{-0.5f, +0.5f, -0.5f}, { 0,  0, -1}, BLACK},   //3  - left upper back - back
    {{-0.5f, +0.5f, -0.5f}, { 0,  1,  0}, BLACK},   //4  - left upper back - upper
    {{-0.5f, +0.5f, -0.5f}, {-1,  0,  0}, BLACK},   //5  - left upper back - left

    {{+0.5f, +0.5f, -0.5f}, { 0,  0, -1}, RED_1},   //6  - right upper back - back
    {{+0.5f, +0.5f, -0.5f}, { 0,  1,  0}, RED_1},   //7  - right upper back - upper
    {{+0.5f, +0.5f, -0.5f}, { 1,  0,  0}, RED_1},   //8  - right upper back - right

    {{+0.5f, -0.5f, -0.5f}, { 0,  0, -1}, GREEN_1}, //9  - right lower back - back
    {{+0.5f, -0.5f, -0.5f}, { 0, -1,  0}, GREEN_1}, //10 - right lower back - lower
    {{+0.5f, -0.5f, -0.5f}, { 1,  0,  0}, GREEN_1}, //11 - right lower back - right

    {{-0.5f, -0.5f, +0.5f}, { 0,  0,  1}, BLUE_1},  //12 - left lower front - front
    {{-0.5f, -0.5f, +0.5f}, { 0, -1,  0}, BLUE_1},  //13 - left lower front - lower
    {{-0.5f, -0.5f, +0.5f}, {-1,  0,  0}, BLUE_1},  //14 - left lower front - left

    {{-0.5f, +0.5f, +0.5f}, { 0,  0,  1}, YELLOW},  //15 - left upper front - front
    {{-0.5f, +0.5f, +0.5f}, { 0,  1,  0}, YELLOW},  //16 - left upper front - upper
    {{-0.5f, +0.5f, +0.5f}, {-1,  0,  0}, YELLOW},  //17 - left upper front - left

    {{+0.5f, +0.5f, +0.5f}, { 0,  0,  1}, CYAN},    //18 - right upper front - front
    {{+0.5f, +0.5f, +0.5f}, { 0,  1,  0}, CYAN},    //19 - right upper front - upper
    {{+0.5f, +0.5f, +0.5f}, { 1,  0,  0}, CYAN},    //20 - right upper front - right

    {{+0.5f, -0.5f, +0.5f}, { 0,  0,  1}, MAGENTA}, //21 - right lower front - front
    {{+0.5f, -0.5f, +0.5f}, { 0, -1,  0}, MAGENTA}, //22 - right lower front - lower
    {{+0.5f, -0.5f, +0.5f}, { 1,  0,  0}, MAGENTA}, //23 - right lower front - right
};

short Cube::CubeIndices[] =
{
    0,   3,  6,    // side 1 - back
    0,   6,  9,
    12, 18, 15,    // side 2 - front
    12, 21, 18,
    14,  5,  2,    // side 3 - left
    14, 17,  5,
    11,  8, 20,    // side 4 - right
     11, 20, 23,
     4, 16, 19,    // side 5 - top
     4, 19,  7,
    13,  1, 10,    // side 6 - bottom
    13, 10, 22,
};

InitRenderData Cube::CubeRenderData =
{
    VertexDeclElements,
    D3DPT_TRIANGLELIST,
    CubeVertices,
    CubeIndices,
    24,
    12,
    3 * 12,
    "BasicTechBlackBorder",
};

void Cube::Init(IDirect3DDevice9* pDevice, btDiscreteDynamicsWorld* pWorld)
{
    pRenderData = new RenderData(pDevice, CubeRenderData);
    Cube::g_pBtDynamicsWorld = pWorld;
}

void Cube::OnLostDevice()
{
    ASSERT(pRenderData);
    pRenderData->OnLostDevice();
}

void Cube::OnResetDevice()
{
    ASSERT(pRenderData);
    pRenderData->OnResetDevice();
}

void Cube::Destroy()
{
    ASSERT(pRenderData);
    delete pRenderData;
}

RenderData* Cube::GetRenderData()
{
    return pRenderData;
}


/***************************************************************
* Instance Data
***************************************************************/

Cube::Cube(bool render,
           bool physics,
           const btVector3& pos, 
           float scale,
           const D3DCOLORVALUE& color,
           short collisionGroup,
           short collisionMask,
           const btVector3& vel) :
               ObjectData(pos, btQuaternion(0,0,0,1), scale, color, collisionGroup, collisionMask, vel)
{
    ASSERT(Cube::g_pBtDynamicsWorld != NULL);   // Make sure Cube::Init() was called

    if (render)
    {
        SetRenderData(pRenderData);
    }

    if (physics)
    {
        InitPhysicsData cubePhysicsData =
        {
            new btBoxShape(btVector3(0.5f*scale,0.5f*scale,0.5f*scale)),
            collisionGroup,
            collisionMask,
            m_scale*m_scale*m_scale,
            m_pos,
            m_rot,
            vel
        };
        SetPhysicsData(new PhysicsData(g_pBtDynamicsWorld, cubePhysicsData));
    }
}

Cube::~Cube()
{
    if (m_pPhysicsData)
    {
        delete m_pPhysicsData;
    }
}
