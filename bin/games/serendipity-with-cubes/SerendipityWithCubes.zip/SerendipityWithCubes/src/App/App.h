
#pragma once

#include "Common.h"

class App{

public:
    virtual ~App(){};

    virtual void Clean() = 0;
    virtual void CheckMessage(MSG* pMsg) = 0;
    virtual void Reset() = 0;
    virtual void ToggleFullscreen() = 0;

protected:
    App(){};
};

static LRESULT CALLBACK WindowProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    switch(message)
    {
        case WM_DESTROY:
            PostQuitMessage(0);
            return 0;
            break;

	    case WM_KEYDOWN:
		    if( wParam == VK_ESCAPE )
            {
                PostQuitMessage(0);
                return 0;
            }
            break;
    }

    return DefWindowProc (hWnd, message, wParam, lParam);
}