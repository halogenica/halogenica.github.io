
#pragma once

#include "Common.h"

enum InputKey
{
    // Absolutes
    LALT,
    MOUSE_LEFT,
    MOUSE_RIGHT,
    MOUSE_MIDDLE,
    SPACE,

    // Movement
    MOVE_LEFT,
    MOVE_RIGHT,
    MOVE_UP,
    MOVE_DOWN,
    MOVE_FORWARD,
    MOVE_BACK,

    // Action
    SHOOT,
    SHOOT_SPECIAL,

    // Function
    TOGGLE_FULLSCREEN,
    TOGGLE_GRAVITY,
    TOGGLE_COLLECTOR,
    TOGGLE_STATS,
    COLLECTOR_POINT,
    COLLECTOR_SQUARE,
    COLLECTOR_CUBE,
    WORLD_INC_DIM,
    WORLD_DEC_DIM,
    WORLD_INC_COLORS,
    WORLD_DEC_COLORS,
    WORLD_RESTART,

    // Editor
    ADD_CAMERA_NODE,
    DEL_CAMERA_NODE,
    SNAP_CAMERA_NODE,
    INTERPOLATE_CAMERA_NODE,

};

class Input
{
public:
    virtual ~Input(){};

    virtual void Poll() = 0;
    virtual void OnLostDevice() = 0;
    virtual void OnResetDevice() = 0;

	virtual bool KeyDown(InputKey key) = 0;
    virtual bool KeyPressed(InputKey key) = 0;
	virtual bool MouseButtonDown(InputKey key) = 0;
    virtual bool MouseButtonPressed(InputKey key) = 0;
    virtual bool MouseButtonReleased(InputKey key) = 0;
    virtual float MouseX() = 0;
    virtual float MouseY() = 0;
    virtual float MouseDX() = 0;
	virtual float MouseDY() = 0;
	virtual float MouseDZ() = 0;

protected:
    Input(){};  // pure virtual
};
