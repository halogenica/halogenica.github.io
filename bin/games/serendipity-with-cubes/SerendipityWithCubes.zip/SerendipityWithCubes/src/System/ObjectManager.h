
#pragma once

#include "Pool.h"
#include "Camera.h"
//#include "Collector.h"
#include "Plane.h"
#include "Cube.h"
#include "Plank.h"
//#include "CubeParticle.h"
//#include "Emitter.h"
#include "Player.h"
#include "PlayerField.h"
#include "Enemy.h"
#include "Asset.h"
//#include "Level.h"
#include "World.h"
#include "Screens.h"

#ifdef EDITOR
#include "CameraEditor.h"
#endif

enum GAME_STATE
{
    NEW_GAME_SCREEN_1,
    NEW_GAME_SCREEN_2,
    NEW_GAME_SCREEN_3,
    PLAYING,
    GAME_OVER,
    GAME_WON,
};

class ObjectManager
{
public:
    static void Init();
    static void FinalizeScene();
    static void Update(float dt);
    static void Render();
    static void Reset();
    static void Destroy();

    static GAME_STATE           gameState;
    static Assimp::Importer*    pAiImporter;  // the asset importer
    static Camera*              pCamera;      // the camera for the scene
    static Pool<Asset*>*        pAssets;      // TODO: remove later?
    static Plane*               pGround;      // TODO: remove, just a hack until assets have physics
    static World*               pWorld;
    static Screens*             pScreens;
    static bool                 gravity;      // toggle to enable or disable gravity
    static float                repeatCount;  // counts up to a value before repeat input is triggered.
    static UINT                 worldDim;
    static UINT                 worldColors;
    static bool                 displayStats;

#ifdef EDITOR
    static CameraEditor*       pCameraEditor;
#endif

};