
#include "Camera.h"
#include "Input.h"


Camera::Camera(const D3DXVECTOR3& pos, const D3DXVECTOR3& orientation) : m_pos(pos),
                                                                         m_orientation(orientation),
                                                                         m_radius(150),
                                                                         m_viewBasis(D3DXVECTOR3(0,0,1)),
                                                                         m_upBasis(D3DXVECTOR3(0,1,0)),
                                                                         m_rightBasis(D3DXVECTOR3(1,0,0)),
                                                                         m_view(D3DXVECTOR3(0,0,1)),
                                                                         m_up(D3DXVECTOR3(0,1,0)),
                                                                         m_right(D3DXVECTOR3(1,0,0))
{

}

Camera::~Camera()
{

}

D3DXMATRIX Camera::Interpolate(float dt)
{
    m_splineData.Interpolate(dt, m_pos, m_orientation);

    D3DXMATRIX matRot;
    D3DXMATRIX matTrans;

    D3DXMatrixRotationYawPitchRoll(&matRot, m_orientation.y, m_orientation.x, m_orientation.z);
    D3DXMatrixTranslation(&matTrans, m_pos.x, m_pos.y, m_pos.z);

    // View and up vectors
    D3DXVec3TransformCoord(&m_view, &m_viewBasis, &matRot);
    D3DXVec3TransformCoord(&m_up, &m_upBasis, &matRot);

    // Translation relative to the camera orientation
    D3DXVec3Normalize( &m_view, &m_view );
    D3DXVec3Cross( &m_right, &m_up, &m_view );
    D3DXVec3Normalize( &m_right, &m_right );
    D3DXVec3Normalize( &m_up, &m_up );

    // Final view matrix
    m_matView = matTrans * matRot;

    return m_matView;
}

D3DXMATRIX Camera::Render()
{
    D3DXMatrixPerspectiveFovLH(&m_matProj,
                               FOV,         // the horizontal field of view
                               ASPECT,      // aspect ratio
                               NEAR_CLIP,   // the near view-plane
                               FAR_CLIP);   // the far view-plane

    g_pDevice->SetTransform(D3DTS_VIEW, &m_matView);
    g_pDevice->SetTransform(D3DTS_PROJECTION, &m_matProj);

    return m_matView * m_matProj;
}

D3DXMATRIX Camera::Update(float dt)
{

    D3DXVECTOR3 relPos = D3DXVECTOR3(0,0,0);

    D3DXMATRIX matRot;

    // Adjust orientation
    if (g_pInput->MouseButtonDown(MOUSE_RIGHT))
    {
        m_orientation.y += g_pInput->MouseDX() / 100.0f;
        m_orientation.x += g_pInput->MouseDY() / 100.0f;
    }

    m_radius -= g_pInput->MouseDZ() / 50.0f;

    // If we rotate over 360 degrees, just roll back to 0
	if (fabsf(m_orientation.x) >= 2.0f * PI) 
    {
		m_orientation.x = 0.0f;
    }
	if (fabsf(m_orientation.y) >= 2.0f * PI) 
    {
		m_orientation.y = 0.0f;
    }

    // Don't let radius get too small or too large
    if (m_radius < 100.0f)
    {
	    m_radius = 100.0f;
    }
    if (m_radius > 400.0f)
    {
	    m_radius = 400.0f;
    }

    // Rotation matrix
    D3DXMatrixRotationYawPitchRoll(&matRot, m_orientation.y, m_orientation.x, m_orientation.z);

    // View and up vectors
    D3DXVec3TransformCoord(&m_view, &m_viewBasis, &matRot);
    D3DXVec3TransformCoord(&m_up, &m_upBasis, &matRot);

    // Adjust position
    D3DXVec3Normalize( &m_view, &m_view );
    m_pos = -m_view*m_radius;

    // Final view matrix
    m_view += m_pos;
    D3DXMatrixLookAtLH( &m_matView, &m_pos, &m_view, &m_up );

    return m_matView;
}
