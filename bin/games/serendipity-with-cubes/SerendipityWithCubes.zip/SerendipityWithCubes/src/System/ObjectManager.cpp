
#pragma once

#include "ObjectManager.h"

GAME_STATE          ObjectManager::gameState    = NEW_GAME_SCREEN_1;
Assimp::Importer*   ObjectManager::pAiImporter  = NULL;
Camera*             ObjectManager::pCamera      = NULL;
Pool<Asset*>*       ObjectManager::pAssets      = NULL;
Plane*              ObjectManager::pGround      = NULL;
World*              ObjectManager::pWorld       = NULL;
Screens*            ObjectManager::pScreens     = NULL;
bool                ObjectManager::gravity      = true;
bool                ObjectManager::displayStats = false;
float               ObjectManager::repeatCount  = 0;
UINT                ObjectManager::worldDim     = 4;
UINT                ObjectManager::worldColors  = 3;

#ifdef EDITOR
CameraEditor*       ObjectManager::pCameraEditor= NULL;    
#endif


void ObjectManager::Init()
{
    pAiImporter = new Assimp::Importer();

    // Must call Init on all shapes
    Asset::Init(g_pDevice, g_pBtDynamicsWorld, pAiImporter);
    Cube::Init(g_pDevice, g_pBtDynamicsWorld);
    Plane::Init(g_pDevice, g_pBtDynamicsWorld);
    Plank::Init(g_pDevice, g_pBtDynamicsWorld);
    World::Init();

    repeatCount = 0;

    pCamera = new Camera(D3DXVECTOR3(0, 0, -150), D3DXVECTOR3(0, 0, 0));
    pAssets = new Pool<Asset*>;
    pWorld = new World(g_pDevice, pCamera, worldDim, worldColors, 20);
    pScreens = new Screens(g_pDevice);

    if (gravity)
    {
        g_pBtDynamicsWorld->setGravity(btVector3(0, GRAVITY_CONST, 0));
    }
    else
    {
        g_pBtDynamicsWorld->setGravity(btVector3(0, 0, 0));
    }

    // Add the ground
    btVector3 groundPos = btVector3(0,-150,0);
    Asset* pAsset = new Asset("res\\ground_normals.obj");
    pAsset->SetPosition(groundPos);
    ObjectManager::pAssets->Add(pAsset);

    Plane* pPlane = new Plane(false, true, groundPos, 1000, WHITE, COL_GROUND, COL_EVERYTHING, btVector3(0,0,0));
    ObjectManager::pGround = pPlane;

#ifdef EDITOR
    pCameraEditor = new CameraEditor(pCamera);    
#endif

}

void ObjectManager::Destroy()
{
    if (pGround)
    {
        delete pGround;
    }

    delete pWorld;
    delete pScreens;
//    delete pAssets;
    delete pCamera;
    delete pAiImporter; // Note that the asset importer will destroy all scene pointers as well.

    World::Destroy();
    Asset::Destroy();
    Cube::Destroy();
    Plane::Destroy();
    Plank::Destroy();
}

void ObjectManager::FinalizeScene()
{
#ifdef EDITOR
    pCameraEditor->SetCamera(pCamera);
#endif
    pWorld->SetCamera(pCamera);
}

void ObjectManager::Update(float dt)
{
    g_pInput->Poll();

    /*
    // Toggle fullscreen
    if (g_pInput->KeyPressed(TOGGLE_FULLSCREEN))
    {
        // Toggle fullscreen and reset the device
        g_pApp->ToggleFullscreen();
        Reset();
    }

    // Toggle gravity
    if (g_pInput->KeyPressed(TOGGLE_GRAVITY))
    {
        gravity = !gravity;
        if (gravity)
        {
            g_pBtDynamicsWorld->setGravity(btVector3(0, GRAVITY_CONST, 0));
        }
        else
        {
            g_pBtDynamicsWorld->setGravity(btVector3(0, 0, 0));
        }
    }
    */

    if (g_pInput->KeyPressed(SPACE) || g_pInput->MouseButtonPressed(MOUSE_LEFT))
    {
        switch (gameState)
        {
            case NEW_GAME_SCREEN_1:
                gameState = NEW_GAME_SCREEN_2;
                break;
            case NEW_GAME_SCREEN_2:
                gameState = NEW_GAME_SCREEN_3;
                break;
            case NEW_GAME_SCREEN_3:
                gameState = PLAYING;
                break;
            default:
                break;
        }
    }

    if (g_pInput->KeyPressed(TOGGLE_STATS))
    {
        displayStats = !displayStats;
    }

    if (g_pInput->KeyPressed(WORLD_INC_DIM))
    {
        if (worldDim < 9)
        {
            delete pWorld;
            ++worldDim;
            pWorld = new World(g_pDevice, pCamera, worldDim, worldColors, 20);
        }
    }

    if (g_pInput->KeyPressed(WORLD_DEC_DIM))
    {
        if (worldDim > 3)
        {
            delete pWorld;
            --worldDim;
            pWorld = new World(g_pDevice, pCamera, worldDim, worldColors, 20);
        }
    }

    if (g_pInput->KeyPressed(WORLD_INC_COLORS))
    {
        if (worldColors < 5)
        {
            delete pWorld;
            ++worldColors;
            pWorld = new World(g_pDevice, pCamera, worldDim, worldColors, 20);
        }
    }

    if (g_pInput->KeyPressed(WORLD_DEC_COLORS))
    {
        if (worldColors > 2)
        {
            delete pWorld;
            --worldColors;
            pWorld = new World(g_pDevice, pCamera, worldDim, worldColors, 20);
        }
    }

    if (g_pInput->KeyPressed(WORLD_RESTART))
    {
        delete pWorld;
        pWorld = new World(g_pDevice, pCamera, worldDim, worldColors, 20);
        gameState = PLAYING;
    }

    // Update camera position
    pCamera->Update(dt);
#ifdef EDITOR
    pCameraEditor->Update(dt);  //TODO: why can't I set matView here?
#endif

    pWorld->Update(dt);

    pAssets->Update(dt);

    if (pGround)
    {
        pGround->Update(dt);
    }
    
}

void ObjectManager::Render()
{
    D3DXMATRIX matVP = pCamera->Render();

    pWorld->Draw(matVP);

    switch (gameState)
    {
        case NEW_GAME_SCREEN_1:
            pScreens->Draw();
            break;
        case NEW_GAME_SCREEN_2:
            pScreens->Draw();
            break;
        case NEW_GAME_SCREEN_3:
            pScreens->Draw();
            break;
        case GAME_OVER:
            pScreens->Draw();
            break;
        case GAME_WON:
            pScreens->Draw();
            break;
        default:
            break;
    }

    if (pGround)
    {
        // TODO: ground renderable is an asset. FIX! poor design. 
        // TODO: Does each renderable object have an asset?
        pGround->Draw(matVP);
    }

    pAssets->Draw(matVP);

    if (displayStats)
    {
        g_pStats->display();
    }
}


void ObjectManager::Reset()
{
    Pool<Asset*>::const_iterator assetItr;

    // Prepare for a device lost
    Cube::OnLostDevice();
    Plane::OnLostDevice();
    Plank::OnLostDevice();

    g_pStats->OnLostDevice();

    for (assetItr = pAssets->begin(); assetItr != pAssets->end(); ++assetItr)
    {
        (*assetItr)->OnLostDevice();
    }

    if (pGround)
    {
        pGround->OnLostDevice();
    }

    pWorld->OnLostDevice();

    // Reset the device
    g_pApp->Reset();   // TODO: Should app reset the object manager?
    Cube::OnResetDevice();
    Plane::OnResetDevice();
    Plank::OnResetDevice();

    // Reset all the objects that require resetting
    g_pStats->OnResetDevice();

    for (assetItr = pAssets->begin(); assetItr != pAssets->end(); ++assetItr)
    {
        (*assetItr)->OnResetDevice();
    }

    if (pGround)
    {
        pGround->OnResetDevice();
    }

    pWorld->OnResetDevice();
}
