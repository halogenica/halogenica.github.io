
#pragma once

#include "Common.h"
#include "SplineData.h"

class Camera{
public:
    Camera(const D3DXVECTOR3& pos, const D3DXVECTOR3& orientation);
    ~Camera();
    D3DXMATRIX Render();
    D3DXMATRIX Update(float dt);
    D3DXMATRIX Interpolate(float dt);
    D3DXVECTOR3 GetPickRay(float x, float y);

	D3DXVECTOR3 m_pos;
    D3DXVECTOR3 m_orientation;
    float m_radius;
    D3DXMATRIX m_matView;
    D3DXMATRIX m_matProj;
    const D3DXVECTOR3 m_upBasis;
    const D3DXVECTOR3 m_viewBasis;
    const D3DXVECTOR3 m_rightBasis;
	D3DXVECTOR3 m_view;
	D3DXVECTOR3 m_up;
    D3DXVECTOR3 m_right;
    SplineData m_splineData;
};

inline D3DXVECTOR3 Camera::GetPickRay(float x, float y)
{
    // Picking algorithms from: 
    //
    // http://www.mvps.org/directx/articles/rayproj.htm
    // DX SDK Picking sample
    // Bullet demos

    // Find screen coordinates normalized to -1,1
    D3DXVECTOR3 coord;
    coord.x = ( ( ( 2.0f * x ) / SCREEN_WIDTH ) - 1 );
    coord.y = -( ( ( 2.0f * y ) / SCREEN_HEIGHT ) - 1 );
    coord.z = 1.0f;

//    g_pStats->setCursorPosition(coord.x, coord.y);

    // Back project the ray from screen to the far clip plane
    coord.x /= m_matProj._11;
    coord.y /= m_matProj._22;

    D3DXMATRIX matinv;
    D3DXMatrixInverse(&matinv, NULL, &m_matView);

    coord*=FAR_CLIP;
    D3DXVec3TransformCoord(&coord, &coord, &matinv);

    return coord;
}
