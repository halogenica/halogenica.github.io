
#pragma once

#include <assert.h>
#include <stdio.h>
#include <stdarg.h>

#include "btBulletDynamicsCommon.h"

#include <assimp.hpp>      // C++ importer interface
#include <aiScene.h>       // Output data structure
#include <aiPostProcess.h> // Post processing flags

#include "al.h"
#include "alut.h"

extern "C" {
#include "lua.h"
#include "lualib.h"
#include "lauxlib.h"
}

#include "D3DAPI.h"
#include "App.h"


/**********************************************************\
*    Macros
\**********************************************************/
// Asserts
#if DEBUG
#define ASSERT(x) { if (!(x)) { __debugbreak(); } }
#else
#define ASSERT(x)
#endif
//#define HR(hresult) ASSERT((bool)(S_OK == hresult))
#define CASSERT(predicate) _impl_CASSERT_LINE(predicate,__LINE__,__FILE__)
#define _impl_PASTE(a,b) a##b
#define _impl_CASSERT_LINE(predicate, line, file) \
    typedef char _impl_PASTE(assertion_failed_##file##_,line)[2*!!(predicate)-1];

// Releasing COM objects
#define ReleaseCOM(x) { if(x) { x->Release();x = 0; } }

/**********************************************************\
*    Defines
\**********************************************************/
//#define NULL    ((void *)0)

// define the screen resolution
#define SCREEN_WIDTH    1280
#define SCREEN_HEIGHT   800
#define FOV             D3DXToRadian(45)
#define ASPECT          ((FLOAT)SCREEN_WIDTH / (FLOAT)SCREEN_HEIGHT)
#define NEAR_CLIP       1.0f
#define FAR_CLIP        5000.0f

#define EPSILON         0.0000001
#define GRAVITY_CONST   -20.0f
#define MAX_VELOCITY    500.0f


/**********************************************************\
*    Prototypes
\**********************************************************/
class App;
class Input;


/**********************************************************\
*    Globals
\**********************************************************/
extern App* g_pApp;                                   // the d3d input
extern Input* g_pInput;                               // input
extern btDiscreteDynamicsWorld* g_pBtDynamicsWorld;   // the world


/**********************************************************\
*    Enums
\**********************************************************/
enum CollisionTypes {
    COL_NOTHING     = 0x0,
    COL_GROUND      = 0x1 << 0,
    COL_PARTICLE    = 0x1 << 1,
    COL_BULLET      = 0x1 << 2,
    COL_HITCORE     = 0x1 << 3,

    COL_EVERYTHING  = (0x1 << 4) - 1
};


/**********************************************************\
*    Typedefs
\**********************************************************/
typedef unsigned long ULONG;
typedef unsigned int UINT;


/**********************************************************\
*    Constants
\**********************************************************/
const float INFINITY = FLT_MAX;
const float PI       = 3.14159265358979323f;
const float MATH_EPS = 0.0001f;


/**********************************************************\
*    Helpers
\**********************************************************/
float GetRandomMinMax( float fMin, float fMax );
D3DXVECTOR3 GetRandomVector( void );


/**********************************************************\
*    Inline
\**********************************************************/
inline HRESULT HR( HRESULT hresult)
{
    ASSERT((bool)(S_OK == hresult));
    return hresult;
}

static void DebugPrint(const WCHAR *format, ...)
{
    const DWORD maxlen = 4096;
    WCHAR buf[maxlen];
    va_list args;

    va_start(args, format);
    vswprintf(buf, maxlen, format, args);
    va_end(args);

    OutputDebugString(buf);
}

inline float GetRandomMinMax( float fMin, float fMax )
{
    float fRandNum = (float)rand () / RAND_MAX;
    return fMin + (fMax - fMin) * fRandNum;
}

inline D3DXVECTOR3 GetRandomVector( void )
{
	D3DXVECTOR3 vVector;

    // Pick a random Z between -1.0f and 1.0f.
    vVector.z = GetRandomMinMax( -1.0f, 1.0f );
    
    // Get radius of this circle
    float radius = (float)sqrt(1 - vVector.z * vVector.z);
    
    // Pick a random point on a circle.
    float t = GetRandomMinMax( -D3DX_PI, D3DX_PI );

    // Compute matching X and Y for our Z.
    vVector.x = (float)cosf(t) * radius;
    vVector.y = (float)sinf(t) * radius;

	return vVector;
}
