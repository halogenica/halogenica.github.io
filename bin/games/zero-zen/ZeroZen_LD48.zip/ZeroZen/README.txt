**************************************** 
2-4 Players only! 
Recommend at least 2 controllers!
Xbox 360 controllers for windows, Xbox 360 or PS3 controllers for mac
**************************************** 

http://youtu.be/z3M4f3quD94 

Objective: 
---------- 
Push your opponent into the wall to win! 

Description: 
------------ 
Luftrausers vs SuperSpace____ 

Zero Zen is a fast paced action game about patience and timing. Fly a zero fighter and shoot at your enemies to push them into the red zone. Bullets don't do damage, they just push. Be careful of the kickback! 

360 Controls: 
-------------
- A to fly 
- X to fire 
- Analog stick to steer 

PS3 Controls:
-------------
- X to fly
- Square to fire
- Analog stick to steer

Keyboard Controls:
------------------
Player 1:
- Up to fly 
- Left and right to steer 
- Enter to fire

Player2:
- W to fly
- A and D to steer
- 1 to shoot

Extra Controls: 
--------------- 
- G for GUI options 
- F to fullscreen 
- ESC to quit 



Game by: Michael Romero
