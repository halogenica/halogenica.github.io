Aggrogate: a game by Michael Romero for Ludum Dare 28

Theme "You Only Get One"

Ludum Dare page: http://www.ludumdare.com/compo/ludum-dare-28/?uid=12262
Download from here: https://dl.dropboxusercontent.com/u/1525295/Aggrogate_LD48.zip
Gameplay Video: http://youtu.be/QZAu-uJhVxs


Aggrogate is a 2 player action puzzle game.
Win the game by clearing all cubes of your color range before your opponent.
Clear cubes by connecting 4 or more same-colored cubes

XBOX Controllers:
Right analog stick aims the crosshair
Place light cubes with LB
Place dark cubes with RB

Keyboard:
Left Player Move - WASD
Left Player Light Cube - 1
Left Player Dark Cube - 2
Right Player Move - Arrow Keys
Right Player Light Cube - [
Right Player Dark Cube - ]
"F" key will toggle full-screen
"R" key will restart the round
"ESC" key will exit

Each player views a the same cube puzzle, and by placing cubes cause it to spin.
The challenge is the speed and precision required to place cubes, when your opponent is spinning the puzzle.
The theme comes into play with this shared puzzle.  


Thanks for playing!



http://halogenica.net