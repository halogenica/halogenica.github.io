Controls:
---------
Left Mouse - Trigger chain reaction starting at the large white circle
Right Mouse - Reset
Escape - Exit game

Goal:
-----
Clear all dots on the screen with a single chain reaction.