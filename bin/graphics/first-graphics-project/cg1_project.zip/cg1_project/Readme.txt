Michael Romero
Computer Graphics 1
Project 4

---------
CONTROLS:
---------
F1 - Toggle Fullscreen
F2 - Toggle Perspective/Orthographic
F3 - Toggle Camera Position (Front or Upper Right COrner)

0 - Toggle light source 1 (green/blue source)
1 - Toggle light source 2 (red/orange source)
2 - Toggle texture 1 (side.raw)
3 - Toggle texture 2 (shine.raw)
4 - Toggle material properties 1 (glowing pink rings)
5 - Toggle material properties 2 (glowing blue sphere)

e - Explode/Expand Cube
f - Toggle fog (on by default)
r - Reset the Scene

Left Mouse Button - Click and drag to rotate cube, maintains rotation
Middle Mouse Button - Click and drag to translate cube along the X-Y plane
Right Mouse Button - Click and drag up or down to increase or decrease scale

ESC - Exit